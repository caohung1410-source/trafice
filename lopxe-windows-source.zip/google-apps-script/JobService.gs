function nextTicketNo_() {
  const settings = settingsMap_();
  const prefix = String(settings.TICKET_PREFIX || 'LX').trim().toUpperCase();
  const date = Utilities.formatDate(new Date(), APP.TZ, 'yyyyMMdd');
  const jobs = listObjects_(APP.SHEETS.JOBS);
  const todayCount = jobs.filter(j => String(j.ticketNo || '').startsWith(prefix + date)).length + 1;
  return prefix + date + '-' + ('000' + todayCount).slice(-3);
}

function parseServiceItemsClient_(items) {
  const services = listObjects_(APP.SHEETS.SERVICES);
  return (Array.isArray(items) ? items : []).map(x => {
    const service = services.find(s => String(s.id) === String(x.id || x.serviceId)) || null;
    const name = String(x.name || (service && service.name) || '').trim();
    const qty = Math.max(1, safeNumber_(x.qty || 1));
    const price = Math.max(0, safeNumber_(x.price !== undefined ? x.price : (service ? service.defaultPrice : 0)));
    return { id: service ? service.id : String(x.id || x.serviceId || ''), name, qty, price, amount: qty * price };
  }).filter(x => x.name);
}

function summarizeServiceItems_(items) {
  return items.map(x => x.name).join(', ');
}

function computeServiceAmount_(items) {
  return items.reduce((s, x) => s + safeNumber_(x.amount), 0);
}

function jobToClient_(x) {
  const items = parseJsonArray_(x.serviceItemsJson);
  return Object.assign({}, x, {
    serviceItems: items,
    amount: safeNumber_(x.amount),
    inventoryConfirmed: asBool_(x.inventoryConfirmed),
    isPendingAccounting: String(x.status) === APP.STATUS.TECH_DONE,
    canFinalizeAccounting: asBool_(x.inventoryConfirmed) && String(x.paymentStatus) === APP.PAYMENT.PAID
  });
}

function createBaseJob_(data) {
  const lane = data.laneId ? getByField_(APP.SHEETS.LANES, 'id', data.laneId) : activeLanes_()[0] || null;
  const now = nowIso_();
  return {
    id:newId_('JOB'), ticketNo:nextTicketNo_(), createdAt:now,
    serviceDate:String(data.serviceDate || today_()), plate:normalizePlate_(data.plate),
    customer:String(data.customer || '').trim(), phone:String(data.phone || '').trim(), vehicleType:String(data.vehicleType || '').trim(),
    laneId:lane ? lane.id : '', laneName:lane ? lane.name : '', employeeId:'', employeeName:'',
    serviceItemsJson:'[]', serviceSummary:'', amount:0,
    status:APP.STATUS.RECEIVED, startedAt:'', completedAt:'', closedAt:'', closedBy:'',
    note:String(data.note || '').trim(), techNote:'', imageUrl:String(data.imageUrl || '').trim(), source:String(data.source || 'MANUAL'),
    paymentStatus:APP.PAYMENT.UNPAID, paymentMethod:'', paidAt:'', inventoryConfirmed:false, inventoryConfirmedAt:'', inventoryConfirmedBy:'', accountingNote:''
  };
}

function apiCreateJob(token, data) {
  requireRole_(token, [APP.ROLES.ADMIN, APP.ROLES.TECH]);
  data = data || {};
  if (!normalizePlate_(data.plate)) throw new Error('Nhập biển số xe.');
  const job = createBaseJob_(data);
  appendObject_(APP.SHEETS.JOBS, job);
  if (data.plateEventId) { try { updateById_(APP.SHEETS.PLATE_EVENTS, data.plateEventId, { used:true }); } catch (e) {} }
  return jobToClient_(job);
}

function jobsForDate_(date) {
  const d = String(date || today_());
  return listObjects_(APP.SHEETS.JOBS).filter(x => String(x.serviceDate) === d).map(jobToClient_);
}

function apiManagerDashboard(token, filters) {
  requireRole_(token, APP.ROLES.ADMIN);
  filters = filters || {};
  const date = String(filters.date || today_());
  const jobs = jobsForDate_(date);
  const lanes = activeLanes_();
  const statusMap = {
    received: jobs.filter(x => x.status === APP.STATUS.RECEIVED).length,
    working: jobs.filter(x => x.status === APP.STATUS.WORKING).length,
    techDone: jobs.filter(x => x.status === APP.STATUS.TECH_DONE).length,
    closed: jobs.filter(x => x.status === APP.STATUS.CLOSED).length
  };
  const laneSummary = lanes.map(l => {
    const rows = jobs.filter(x => String(x.laneId) === String(l.id));
    return {
      laneId:l.id, laneName:l.name, cameraCount:safeNumber_(l.cameraCount), total:rows.length,
      received:rows.filter(x => x.status === APP.STATUS.RECEIVED).length,
      working:rows.filter(x => x.status === APP.STATUS.WORKING).length,
      techDone:rows.filter(x => x.status === APP.STATUS.TECH_DONE).length,
      closed:rows.filter(x => x.status === APP.STATUS.CLOSED).length
    };
  });
  const employeeRevenueMap = {};
  jobs.filter(x => x.status === APP.STATUS.CLOSED).forEach(x => {
    const k = x.employeeName || 'Chưa gán';
    if (!employeeRevenueMap[k]) employeeRevenueMap[k] = { employeeName:k, count:0, revenue:0 };
    employeeRevenueMap[k].count += 1;
    employeeRevenueMap[k].revenue += safeNumber_(x.amount);
  });
  return {
    date,
    totalCars:jobs.length,
    revenue:jobs.filter(x => x.status === APP.STATUS.CLOSED).reduce((s,x)=>s + safeNumber_(x.amount), 0),
    collected:jobs.filter(x => x.paymentStatus === APP.PAYMENT.PAID).reduce((s,x)=>s + safeNumber_(x.amount), 0),
    statuses:statusMap,
    lanes:laneSummary,
    employeeRevenue:Object.values(employeeRevenueMap).sort((a,b)=>b.revenue - a.revenue),
    jobs:jobs.sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)))
  };
}

function apiListManagerJobs(token, filters) {
  requireRole_(token, APP.ROLES.ADMIN);
  filters = filters || {};
  let rows = listObjects_(APP.SHEETS.JOBS).map(jobToClient_);
  if (filters.from) rows = rows.filter(x => String(x.serviceDate) >= String(filters.from));
  if (filters.to) rows = rows.filter(x => String(x.serviceDate) <= String(filters.to));
  if (filters.status) rows = rows.filter(x => String(x.status) === String(filters.status));
  if (filters.laneId) rows = rows.filter(x => String(x.laneId) === String(filters.laneId));
  if (filters.plate) rows = rows.filter(x => normalizePlate_(x.plate).includes(normalizePlate_(filters.plate)));
  return rows.sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 500);
}

function apiTechQueue(token, filters) {
  requireRole_(token, [APP.ROLES.ADMIN, APP.ROLES.TECH]);
  filters = filters || {};
  let rows = jobsForDate_(filters.date || today_()).filter(x => x.status !== APP.STATUS.CANCELLED);
  if (filters.laneId) rows = rows.filter(x => String(x.laneId) === String(filters.laneId));
  rows.sort((a,b) => {
    const order = {};
    order[APP.STATUS.WORKING] = 0;
    order[APP.STATUS.RECEIVED] = 1;
    order[APP.STATUS.TECH_DONE] = 2;
    order[APP.STATUS.CLOSED] = 3;
    return (order[a.status] ?? 9) - (order[b.status] ?? 9) || String(a.createdAt).localeCompare(String(b.createdAt));
  });
  return rows;
}

function apiTechSaveJob(token, id, data) {
  requireRole_(token, [APP.ROLES.ADMIN, APP.ROLES.TECH]);
  data = data || {};
  const current = getByField_(APP.SHEETS.JOBS, 'id', id);
  if (!current) throw new Error('Không tìm thấy lượt xe.');
  const employee = data.employeeId ? getByField_(APP.SHEETS.EMPLOYEES, 'id', data.employeeId) : null;
  const lane = data.laneId ? getByField_(APP.SHEETS.LANES, 'id', data.laneId) : null;
  const items = parseServiceItemsClient_(data.serviceItems);
  const amount = data.amount === '' || data.amount === null || data.amount === undefined ? safeNumber_(computeServiceAmount_(items)) : Math.max(0, safeNumber_(data.amount));
  const patch = {
    employeeId: employee ? employee.id : current.employeeId,
    employeeName: employee ? employee.name : current.employeeName,
    laneId: lane ? lane.id : current.laneId,
    laneName: lane ? lane.name : current.laneName,
    serviceItemsJson: JSON.stringify(items),
    serviceSummary: summarizeServiceItems_(items),
    amount: amount,
    techNote: String(data.techNote || current.techNote || '').trim(),
    note: data.note !== undefined ? String(data.note || '').trim() : current.note,
    startedAt: current.startedAt || nowIso_(),
    status: current.status === APP.STATUS.RECEIVED ? APP.STATUS.WORKING : current.status
  };
  return jobToClient_(updateById_(APP.SHEETS.JOBS, id, patch));
}

function validateTechCompleteInput_(data) {
  if (!String(data.employeeId || '').trim()) throw new Error('Kỹ thuật phải chọn nhân viên.');
  if (!String(data.laneId || '').trim()) throw new Error('Kỹ thuật phải chọn làn xe.');
  const items = parseServiceItemsClient_(data.serviceItems);
  if (!items.length) throw new Error('Kỹ thuật phải chọn ít nhất 1 dịch vụ.');
  if (data.amount === '' || data.amount === null || data.amount === undefined || !Number.isFinite(Number(data.amount))) throw new Error('Kỹ thuật phải nhập số tiền.');
  return items;
}

function apiTechComplete(token, id, data) {
  requireRole_(token, [APP.ROLES.ADMIN, APP.ROLES.TECH]);
  data = data || {};
  const current = getByField_(APP.SHEETS.JOBS, 'id', id);
  if (!current) throw new Error('Không tìm thấy lượt xe.');
  const items = validateTechCompleteInput_(data);
  const employee = getByField_(APP.SHEETS.EMPLOYEES, 'id', data.employeeId);
  const lane = getByField_(APP.SHEETS.LANES, 'id', data.laneId);
  if (!employee) throw new Error('Nhân viên không hợp lệ.');
  if (!lane) throw new Error('Làn xe không hợp lệ.');
  const amount = Math.max(0, safeNumber_(data.amount));
  const updated = updateById_(APP.SHEETS.JOBS, id, {
    employeeId:employee.id, employeeName:employee.name,
    laneId:lane.id, laneName:lane.name,
    serviceItemsJson:JSON.stringify(items), serviceSummary:summarizeServiceItems_(items), amount:amount,
    techNote:String(data.techNote || current.techNote || '').trim(), note:data.note !== undefined ? String(data.note || '').trim() : current.note,
    startedAt:current.startedAt || nowIso_(), completedAt:nowIso_(),
    status:APP.STATUS.TECH_DONE
  });
  return jobToClient_(updated);
}

function accountingBaseRows_(filters) {
  filters = filters || {};
  let rows = listObjects_(APP.SHEETS.JOBS).map(jobToClient_).filter(x => [APP.STATUS.TECH_DONE, APP.STATUS.CLOSED].includes(String(x.status)));
  if (filters.from) rows = rows.filter(x => String(x.serviceDate) >= String(filters.from));
  if (filters.to) rows = rows.filter(x => String(x.serviceDate) <= String(filters.to));
  if (filters.plate) rows = rows.filter(x => normalizePlate_(x.plate).includes(normalizePlate_(filters.plate)));
  if (filters.status) rows = rows.filter(x => String(x.status) === String(filters.status));
  return rows.sort((a,b)=>String(b.completedAt || b.createdAt).localeCompare(String(a.completedAt || a.createdAt)));
}

function apiAccountingSummary(token, filters) {
  requireRole_(token, [APP.ROLES.ADMIN, APP.ROLES.ACCOUNTING]);
  const date = String((filters && filters.date) || today_());
  const rows = jobsForDate_(date);
  return {
    date,
    totalCars:rows.length,
    working:rows.filter(x => x.status === APP.STATUS.WORKING).length,
    waiting:rows.filter(x => x.status === APP.STATUS.RECEIVED).length,
    revenue:rows.filter(x => x.status === APP.STATUS.CLOSED).reduce((s,x)=>s + safeNumber_(x.amount), 0),
    pendingCount:rows.filter(x => x.status === APP.STATUS.TECH_DONE).length,
    pendingRows:rows.filter(x => x.status === APP.STATUS.TECH_DONE)
  };
}

function apiAccountingList(token, filters) {
  requireRole_(token, [APP.ROLES.ADMIN, APP.ROLES.ACCOUNTING]);
  return accountingBaseRows_(filters).slice(0, 500);
}

function apiAccountingFinalize(token, id, data) {
  const session = requireRole_(token, [APP.ROLES.ADMIN, APP.ROLES.ACCOUNTING]);
  data = data || {};
  const current = getByField_(APP.SHEETS.JOBS, 'id', id);
  if (!current) throw new Error('Không tìm thấy lượt xe.');
  if (String(current.status) !== APP.STATUS.TECH_DONE) throw new Error('Lượt xe này chưa ở trạng thái chờ kế toán xác nhận.');
  if (!data.confirmInventory) throw new Error('Chưa xác nhận xuất kho vật tư/lốp.');
  if (!data.confirmPaid) throw new Error('Chưa xác nhận đã thu tiền.');
  const method = String(data.paymentMethod || 'Tiền mặt').trim();
  const updated = updateById_(APP.SHEETS.JOBS, id, {
    inventoryConfirmed:true,
    inventoryConfirmedAt:nowIso_(),
    inventoryConfirmedBy:roleLabel_(session.role),
    paymentStatus:APP.PAYMENT.PAID,
    paymentMethod:method,
    paidAt:nowIso_(),
    accountingNote:String(data.accountingNote || current.accountingNote || '').trim(),
    status:APP.STATUS.CLOSED,
    closedAt:nowIso_(),
    closedBy:roleLabel_(session.role)
  });
  return jobToClient_(updated);
}

function apiNotificationFeed(token, since) {
  requireRole_(token, [APP.ROLES.ADMIN, APP.ROLES.ACCOUNTING]);
  let rows = listObjects_(APP.SHEETS.JOBS).map(jobToClient_).filter(x => x.status === APP.STATUS.TECH_DONE);
  if (since) rows = rows.filter(x => String(x.completedAt || '') > String(since));
  return rows.sort((a,b)=>String(a.completedAt).localeCompare(String(b.completedAt))).slice(-20);
}

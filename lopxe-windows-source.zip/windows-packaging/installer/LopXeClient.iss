#define MyAppName "Lốp Xe Client"
#define MyAppVersion "1.4.1"
#define MyAppExeName "LopXeClient.exe"

[Setup]
AppId={{6CCCD89A-EDB9-4D62-A391-CC01E39A97DF}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={autopf}\Lop Xe Pro Client
DefaultGroupName=Lốp Xe Pro
OutputDir=..\output
OutputBaseFilename=LopXe_Client_Setup_1.4.1
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExeName}

[Files]
Source: "..\output\client\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\output\MicrosoftEdgeWebview2Setup.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall

[Icons]
Name: "{autodesktop}\Lốp Xe Client"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Lốp Xe Client"; Filename: "{app}\{#MyAppExeName}"

[Run]
Filename: "{tmp}\MicrosoftEdgeWebview2Setup.exe"; Parameters: "/silent /install"; StatusMsg: "Đang kiểm tra Microsoft Edge WebView2..."; Flags: waituntilterminated
Filename: "{app}\{#MyAppExeName}"; Description: "Mở Lốp Xe Client"; Flags: nowait postinstall skipifsilent

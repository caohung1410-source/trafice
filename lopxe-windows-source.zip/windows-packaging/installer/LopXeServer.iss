#define MyAppName "Lốp Xe Server"
#define MyAppVersion "1.4.1"
#define MyAppExeName "LopXeServerManager.exe"

[Setup]
AppId={{9CB715C8-3A66-4630-98FD-29129E6DB831}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={autopf}\Lop Xe Pro Server
DefaultGroupName=Lốp Xe Pro
OutputDir=..\output
OutputBaseFilename=LopXe_Server_Setup_1.4.1
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExeName}

[Dirs]
Name: "{commonappdata}\LopXePro"; Permissions: users-modify
Name: "{commonappdata}\LopXePro\logs"; Permissions: users-modify
Name: "{commonappdata}\LopXePro\models"; Permissions: users-modify

[Files]
Source: "..\output\server\*"; DestDir: "{app}"; Excludes: "models\*"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\output\server\server_config.example.json"; DestDir: "{commonappdata}\LopXePro"; DestName: "server_config.json"; Flags: onlyifdoesntexist
Source: "..\output\server\models\*"; DestDir: "{commonappdata}\LopXePro\models"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autodesktop}\Lốp Xe Server"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Lốp Xe Server"; Filename: "{app}\{#MyAppExeName}"
Name: "{commonstartup}\Lốp Xe Server Service"; Filename: "{app}\LopXeServiceHost.exe"; WorkingDir: "{app}"

[Run]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""Lop Xe Server Discovery"" dir=in action=allow protocol=UDP localport=43991 program=""{app}\LopXeServiceHost.exe"""; Flags: runhidden
Filename: "{app}\{#MyAppExeName}"; Description: "Mở cấu hình Lốp Xe Server"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{sys}\taskkill.exe"; Parameters: "/F /IM LopXeServiceHost.exe"; Flags: runhidden; RunOnceId: "StopHost"
Filename: "{sys}\taskkill.exe"; Parameters: "/F /IM LopXeAI.exe"; Flags: runhidden; RunOnceId: "StopAI"
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""Lop Xe Server Discovery"""; Flags: runhidden

[UninstallDelete]
Type: files; Name: "{commonappdata}\LopXePro\stop.flag"

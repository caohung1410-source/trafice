"""Entry point bundled into LopXeServer.exe."""
from __future__ import annotations

import os
import socket
import sys
import threading
import webbrowser
from pathlib import Path

PORT = 8000


def running() -> bool:
    try:
        with socket.create_connection(("127.0.0.1", PORT), timeout=0.4):
            return True
    except OSError:
        return False


def main() -> None:
    data = Path(os.environ.get("PROGRAMDATA", str(Path.home()))) / "LopXePro"
    data.mkdir(parents=True, exist_ok=True)
    models = data / "easyocr-models"
    models.mkdir(parents=True, exist_ok=True)
    os.environ["LOPXE_DATA_DIR"] = str(data)
    os.environ["LOPXE_EASYOCR_MODEL_DIR"] = str(models)
    os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "rtsp_transport;tcp")
    background = "--background" in sys.argv
    url = f"http://127.0.0.1:{PORT}"
    if running():
        if not background:
            webbrowser.open(url)
        return
    if not background:
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    import uvicorn
    import server
    uvicorn.run(server.app, host="0.0.0.0", port=PORT, log_level="warning")


if __name__ == "__main__":
    main()

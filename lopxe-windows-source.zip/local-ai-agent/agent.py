from __future__ import annotations
import argparse
import logging
import os
import sys
import time
from datetime import datetime
from pathlib import Path
import cv2
import yaml
from anpr import ANPREngine, PlateVoter
from gas_client import GASClient

BASE=Path(__file__).resolve().parent


def load_cfg(path:str):
    p=Path(path)
    if not p.is_absolute(): p=BASE/p
    with p.open('r',encoding='utf-8') as f: return yaml.safe_load(f) or {}


def setup_logging(cfg):
    logcfg=cfg.get('logging',{})
    level=getattr(logging,str(logcfg.get('level','INFO')).upper(),logging.INFO)
    logfile=BASE/str(logcfg.get('file','logs/agent.log'))
    logfile.parent.mkdir(parents=True,exist_ok=True)
    logging.basicConfig(level=level,format='%(asctime)s | %(levelname)s | %(message)s',handlers=[logging.StreamHandler(sys.stdout),logging.FileHandler(logfile,encoding='utf-8')])


def resolve_camera(cfg,gas:GASClient):
    cam=cfg.setdefault('camera',{})
    if cam.get('remote_config',True):
        try:
            data=gas.get_agent_config(str(cam.get('camera_id','')))
            remote=data.get('camera')
            if remote:
                cam['camera_id']=remote.get('id') or cam.get('camera_id','')
                cam['name']=remote.get('name') or cam.get('name','Camera')
                cam['rtsp_url']=remote.get('rtspUrl') or cam.get('rtsp_url','')
                logging.info('Đã tải cấu hình camera từ Apps Script: %s',cam.get('name'))
        except Exception as e:
            logging.warning('Không tải được remote config, dùng config local: %s',e)
    if not cam.get('rtsp_url'):
        raise RuntimeError('Chưa có RTSP URL. Nhập trong config.yaml hoặc Apps Script.')
    return cam


def open_camera(url:str):
    os.environ.setdefault('OPENCV_FFMPEG_CAPTURE_OPTIONS','rtsp_transport;tcp')
    cap=cv2.VideoCapture(url,cv2.CAP_FFMPEG)
    cap.set(cv2.CAP_PROP_BUFFERSIZE,2)
    return cap


def main():
    ap=argparse.ArgumentParser(description='Lop Xe Pro Local AI Agent')
    ap.add_argument('--config',default='config.yaml')
    args=ap.parse_args()
    cfg=load_cfg(args.config); setup_logging(cfg)

    gas_cfg=cfg.get('google_apps_script',{})
    gas=GASClient(str(gas_cfg.get('web_app_url','')).strip(),str(gas_cfg.get('api_key','')).strip())
    if not gas.web_app_url or not gas.api_key:
        raise RuntimeError('Thiếu web_app_url hoặc api_key trong config.yaml')

    cam=resolve_camera(cfg,gas)
    ai=cfg.get('ai',{}); agent_cfg=cfg.get('agent',{}); preview=cfg.get('preview',{})
    engine=ANPREngine(cfg)
    voter=PlateVoter(ai.get('vote_window_seconds',2.5),ai.get('vote_min_hits',3),
                     ai.get('vote_min_ratio',.55),ai.get('vote_max_edit_distance',1))
    process_fps=max(.5,float(ai.get('process_fps',5)))
    cooldown=float(ai.get('duplicate_cooldown_seconds',15))
    camera_id=str(cam.get('camera_id','')); camera_name=str(cam.get('name','Camera'))
    reconnect=max(1,float(cam.get('reconnect_seconds',3)))
    show=bool(preview.get('enabled',True)); preview_width=int(preview.get('width',960))

    last_sent={}; last_plate=''; last_hb=time.time(); processed=0; fps_t=time.time(); measured_fps=0.0
    cap=None; next_process=0
    logging.info('Lốp Xe Pro Local AI Agent %s khởi động',agent_cfg.get('version','1.2.3'))
    logging.info('Camera: %s | ONNX detector: %s',camera_name,'ON' if engine.detector.available else 'fallback hình học')

    while True:
        try:
            if cap is None or not cap.isOpened():
                if cap is not None: cap.release()
                logging.info('Kết nối RTSP...')
                cap=open_camera(str(cam['rtsp_url']))
                if not cap.isOpened():
                    logging.error('Không mở được RTSP. Thử lại sau %.0fs',reconnect);time.sleep(reconnect);continue
                logging.info('RTSP OK')

            ok,frame=cap.read()
            if not ok or frame is None:
                logging.warning('Mất frame RTSP, reconnect...');cap.release();cap=None;time.sleep(reconnect);continue

            now=time.time(); overlay=frame
            if now>=next_process:
                next_process=now+1.0/process_fps
                result,cands=engine.infer(frame)
                processed+=1
                if result:
                    plate=result['plate'];conf=result['confidence'];cand=result['candidate']
                    x,y,w,h=cand.box
                    cv2.rectangle(overlay,(x,y),(x+w,y+h),(0,255,0),2)
                    cv2.putText(overlay,f'{plate} {conf:.2f} {result["source"]}',(x,max(25,y-8)),cv2.FONT_HERSHEY_SIMPLEX,.72,(0,255,0),2)
                    voted=voter.add(plate,conf,result['crop'],{
                        'ocrConfidence':round(float(result['ocr_confidence']),4),
                        'detectorConfidence':round(float(result['detector_confidence']),4),
                        'syntaxScore':round(float(result['syntax_score']),4),
                        'detector':result['source'],
                        'ocr':result.get('ocr_meta',{})
                    })
                    if voted:
                        vplate,vconf,vcrop,vmeta=voted
                        key=''.join(ch for ch in vplate if ch.isalnum())
                        if now-last_sent.get(key,0)>=cooldown:
                            try:
                                resp=gas.send_plate(camera_id=camera_id,camera_name=camera_name,plate=vplate,confidence=vconf,
                                                    image_bgr=vcrop,duplicate_window_sec=int(cooldown),
                                                    timestamp=datetime.now().strftime('%Y-%m-%dT%H:%M:%S'),
                                                    metadata=vmeta)
                                last_sent[key]=now;last_plate=vplate
                                logging.info('GỬI BIỂN SỐ: %s | conf=%.3f | duplicate=%s',vplate,vconf,resp.get('duplicate',False))
                            except Exception as e:
                                logging.error('Gửi GAS thất bại: %s',e)
                else:
                    for c in cands[:3]:
                        x,y,w,h=c.box;cv2.rectangle(overlay,(x,y),(x+w,y+h),(70,150,255),1)

            if now-fps_t>=5:
                measured_fps=processed/max(.001,now-fps_t);processed=0;fps_t=now
            if now-last_hb>=30:
                last_hb=now
                if measured_fps <= 0 and processed > 0:
                    measured_fps = processed / max(.001, now-fps_t)
                try:
                    gas.heartbeat(agent_id=str(agent_cfg.get('id','LX-AGENT-01')),agent_name=str(agent_cfg.get('name','Lop Xe Pro AI')),camera_id=camera_id,version=str(agent_cfg.get('version','1.2.3')),fps=measured_fps,last_plate=last_plate,status='ONLINE',message='RTSP OK')
                except Exception as e: logging.warning('Heartbeat lỗi: %s',e)

            if show:
                h,w=overlay.shape[:2]
                if w>preview_width:
                    scale=preview_width/w;overlay=cv2.resize(overlay,(preview_width,int(h*scale)))
                cv2.putText(overlay,f'Lop Xe Pro AI | {camera_name} | AI {measured_fps:.1f} fps | Q: thoat',(12,28),cv2.FONT_HERSHEY_SIMPLEX,.65,(255,255,255),2)
                cv2.imshow('Lop Xe Pro - Local AI',overlay)
                if cv2.waitKey(1)&0xFF in (ord('q'),27): break
        except KeyboardInterrupt:
            break
        except Exception as e:
            logging.exception('Agent lỗi: %s',e)
            if cap is not None: cap.release();cap=None
            time.sleep(reconnect)

    if cap is not None: cap.release()
    cv2.destroyAllWindows()
    try:
        gas.heartbeat(agent_id=str(agent_cfg.get('id','LX-AGENT-01')),agent_name=str(agent_cfg.get('name','Lop Xe Pro AI')),camera_id=camera_id,version=str(agent_cfg.get('version','1.2.3')),fps=0,last_plate=last_plate,status='OFFLINE',message='Agent stopped')
    except Exception: pass
    logging.info('Agent đã dừng')

if __name__=='__main__': main()

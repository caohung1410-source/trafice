import re
import cv2
import easyocr
import numpy as np
import os
import uuid
import warnings

# Tắt toàn bộ cảnh báo CPU/PyTorch để console luôn sạch
warnings.filterwarnings("ignore")
os.environ["PYTHONWARNINGS"] = "ignore"

# Khởi tạo EasyOCR chế độ tối ưu bộ nhớ. Bộ model được cài riêng ở ProgramData.
MODEL_DIR = os.environ.get("LOPXE_EASYOCR_MODEL_DIR")
reader = easyocr.Reader(['en'], gpu=False, quantize=True,
                        model_storage_directory=MODEL_DIR,
                        download_enabled=not bool(MODEL_DIR))

# Thư mục lưu ảnh cắt (capcut) biển số phục vụ hiển thị trên giao diện và in hóa đơn
DATA_DIR = os.environ.get("LOPXE_DATA_DIR", os.path.dirname(__file__))
SNAPSHOT_DIR = os.path.join(DATA_DIR, "static", "snapshots")
os.makedirs(SNAPSHOT_DIR, exist_ok=True)

def clean_char(c: str) -> str:
    """Khắc phục các lỗi nhầm lẫn OCR phổ biến trên biển số xe cơ giới Việt Nam"""
    c = c.upper().strip()
    mapping = {
        'O': '0', 'D': '0', 'Q': '0', 
        'I': '1', 'L': '1', 
        'Z': '2', 
        'S': '5', 
        'B': '8', 
        'G': '6'
    }
    return mapping.get(c, c)

def preprocess_traffic_plate(plate_crop):
    """
    Tiền xử lý quang học theo chuẩn camera giao thông:
    - Cân bằng sáng thích ứng CLAHE chống lóa đèn pha / nắng gắt
    - Khử nhiễu làm sắc cạnh chữ dập nổi
    """
    if plate_crop is None or plate_crop.size == 0:
        return None

    h, w = plate_crop.shape[:2]
    # Phóng to nếu vùng biển số bị cắt quá nhỏ từ xa
    if h < 60:
        scale = 60.0 / h
        plate_crop = cv2.resize(plate_crop, (int(w * scale), 60), interpolation=cv2.INTER_CUBIC)

    gray = cv2.cvtColor(plate_crop, cv2.COLOR_BGR2GRAY)

    # Tăng cường tương phản cục bộ
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)

    # Lọc song phương giữ biên nét chữ
    denoised = cv2.bilateralFilter(enhanced, 7, 50, 50)
    return denoised

def locate_plate_multiscale(img):
    """
    Dò quét đa tầng (Multi-scale Localization):
    Tìm vùng biển số dựa trên độ tương phản dập nổi kim loại,
    nhận diện chuẩn cả biển vuông 2 dòng (30F-931.71) lẫn biển dài góc nghiêng (49X-6666).
    """
    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Đạo hàm Sobel ngang bắt mật độ chuyển đổi ký tự
    sobel_x = cv2.Sobel(gray, cv2.CV_16S, 1, 0)
    abs_sobel = cv2.convertScaleAbs(sobel_x)
    blur = cv2.GaussianBlur(abs_sobel, (9, 9), 0)
    _, thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # Gắn kết các chữ số thành một khối viền chữ nhật
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (23, 5))
    morph = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

    contours, _ = cv2.findContours(morph, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidates = []

    for c in contours:
        x, y, bw, bh = cv2.boundingRect(c)
        aspect = bw / float(bh)
        area = bw * bh
        
        # Tỷ lệ chuẩn: Biển dài (2.0 - 5.5) hoặc biển vuông (1.0 - 1.8)
        if (1.0 <= aspect <= 5.5) and (w * 0.08 <= bw <= w * 0.85) and (area > 1200):
            # Mở rộng thêm 5% lề để không bị chém vào viền chữ
            px = int(bw * 0.06)
            py = int(bh * 0.08)
            x1, y1 = max(0, x - px), max(0, y - py)
            x2, y2 = min(w, x + bw + px), min(h, y + bh + py)
            candidates.append(img[y1:y2, x1:x2])

    # Dự phòng vị trí gắn biển số thông thường (giữa thân xe đến cản dưới)
    if not candidates:
        candidates.append(img[int(h * 0.35):int(h * 0.85), int(w * 0.15):int(w * 0.85)])

    return candidates

def read_plate_from_image(image_input, save_crop=True):
    """
    Nhận diện biển số như camera ANPR giao thông:
    Tự động ghép định dạng chuẩn và lưu ảnh cắt (capcut) chất lượng cao.
    """
    if isinstance(image_input, str):
        img = cv2.imread(image_input)
    else:
        img = image_input

    if img is None or img.size == 0:
        return "", ""

    h, w = img.shape[:2]
    # Thu phóng ảnh gốc về độ rộng chuẩn 960px để xử lý nhanh (<0.3s) mà không vỡ nét
    if w > 960:
        scale = 960.0 / w
        img = cv2.resize(img, (960, int(h * scale)), interpolation=cv2.INTER_AREA)

    candidates = locate_plate_multiscale(img)
    best_plate = ""
    best_crop = None

    for crop in candidates:
        processed = preprocess_traffic_plate(crop)
        if processed is None:
            continue

        results = reader.readtext(
            processed,
            batch_size=1,
            detail=1,
            paragraph=False,
            allowlist='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ.-'
        )

        # Sắp xếp các dòng text từ trên xuống dưới (cực kỳ quan trọng cho biển vuông 2 dòng)
        results = sorted(results, key=lambda r: r[0][0][1])

        raw_parts = []
        for (bbox, text, prob) in results:
            clean = re.sub(r'[^A-Z0-9]', '', text.upper())
            if len(clean) >= 2 and prob > 0.2:
                raw_parts.append(clean)

        if not raw_parts:
            continue

        full_str = "".join(raw_parts)
        if len(full_str) >= 6:
            # Chuẩn hóa lại ký tự đầu (Mã tỉnh thành)
            prov = clean_char(full_str[0]) + clean_char(full_str[1])
            mid = full_str[2]  # Seri chữ (A, B, C, F, X...)
            tail = "".join([clean_char(c) for c in full_str[3:]])
            standard_flat = prov + mid + tail

            if len(raw_parts) >= 2:
                # Dạng biển vuông 2 dòng (ví dụ: dòng 1 '30F', dòng 2 '93171' -> '30F-93171')
                best_plate = f"{raw_parts[0]}-{raw_parts[1]}"
            else:
                # Dạng biển dài 1 dòng (ví dụ: '49X-6666')
                best_plate = f"{standard_flat[:3]}-{standard_flat[3:]}"

            best_crop = crop
            break

    # Lưu ảnh cắt capcut làm bằng chứng vào static/snapshots
    crop_path = ""
    if best_plate and save_crop:
        try:
            filename = f"{uuid.uuid4().hex[:8]}_{best_plate}.jpg"
            save_path = os.path.join(SNAPSHOT_DIR, filename)
            if best_crop is not None and best_crop.size > 0:
                cv2.imwrite(save_path, best_crop)
            else:
                cv2.imwrite(save_path, img)
            crop_path = f"/static/snapshots/{filename}"
        except Exception:
            pass

    return best_plate, crop_path

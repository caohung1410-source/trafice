from __future__ import annotations

import base64
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

import cv2

from server_config import CONFIG_FILE, DATA_DIR, load_server_config, save_server_config


APP_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent


class CameraDialog(tk.Toplevel):
    def __init__(self, parent, camera=None):
        super().__init__(parent)
        self.title("Cấu hình camera/làn")
        self.geometry("850x665")
        self.resizable(False, False)
        self.result = None
        self.preview_image = None
        camera = camera or {}
        self.vars = {
            "id": tk.StringVar(value=camera.get("id", "")),
            "name": tk.StringVar(value=camera.get("name", "Camera cổng vào")),
            "lane": tk.StringVar(value=camera.get("lane", "Làn 1")),
            "rtsp_url": tk.StringVar(value=camera.get("rtsp_url", "rtsp://admin:password@192.168.1.100:554/Streaming/Channels/101")),
            "enabled": tk.BooleanVar(value=camera.get("enabled", True)),
            "preview": tk.BooleanVar(value=camera.get("preview", False)),
        }
        labels = [("Mã camera", "id"), ("Tên camera", "name"), ("Làn dịch vụ", "lane"), ("Địa chỉ RTSP", "rtsp_url")]
        for row, (label, key) in enumerate(labels):
            ttk.Label(self, text=label).grid(row=row, column=0, sticky="w", padx=12, pady=7)
            ttk.Entry(self, textvariable=self.vars[key], width=68).grid(row=row, column=1, padx=12, pady=7)
        ttk.Checkbutton(self, text="Kích hoạt camera", variable=self.vars["enabled"]).grid(row=4, column=1, sticky="w", padx=12)
        ttk.Checkbutton(self, text="Mở cửa sổ camera khi AI chạy", variable=self.vars["preview"]).grid(row=5, column=1, sticky="w", padx=12)
        preview_box = ttk.LabelFrame(self, text="Ô kiểm tra cấu hình camera", padding=8)
        preview_box.grid(row=6, column=0, columnspan=2, sticky="nsew", padx=12, pady=10)
        self.preview_label = ttk.Label(preview_box, text="Bấm Kiểm tra RTSP để chụp một khung hình", anchor="center")
        self.preview_label.pack(fill="both", expand=True)
        self.preview_status = tk.StringVar(value="Chưa kiểm tra")
        preview_actions = ttk.Frame(preview_box)
        preview_actions.pack(fill="x", pady=(8, 0))
        ttk.Label(preview_actions, textvariable=self.preview_status).pack(side="left")
        ttk.Button(preview_actions, text="Kiểm tra RTSP", command=self.test_rtsp).pack(side="right")
        buttons = ttk.Frame(self)
        buttons.grid(row=7, column=0, columnspan=2, pady=10)
        ttk.Button(buttons, text="Hủy", command=self.destroy).pack(side="left", padx=5)
        ttk.Button(buttons, text="Lưu camera", command=self.save).pack(side="left", padx=5)
        self.transient(parent)
        self.grab_set()

    def test_rtsp(self):
        url = self.vars["rtsp_url"].get().strip()
        if not url.lower().startswith(("rtsp://", "rtsps://")):
            messagebox.showwarning("RTSP chưa đúng", "Địa chỉ camera phải bắt đầu bằng rtsp:// hoặc rtsps://", parent=self)
            return
        self.preview_status.set("Đang kết nối và chụp khung hình…")

        def work():
            cap = None
            try:
                os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "rtsp_transport;tcp|stimeout;5000000")
                cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                frame = None
                deadline = time.time() + 8
                while time.time() < deadline:
                    ok, candidate = cap.read()
                    if ok and candidate is not None:
                        frame = candidate
                        break
                if frame is None:
                    raise RuntimeError("Không nhận được hình trong 8 giây")
                height, width = frame.shape[:2]
                scale = min(790 / max(width, 1), 420 / max(height, 1), 1.0)
                if scale < 1:
                    frame = cv2.resize(frame, (int(width * scale), int(height * scale)))
                ok, encoded = cv2.imencode(".png", frame)
                if not ok:
                    raise RuntimeError("Không tạo được ảnh xem trước")
                png = base64.b64encode(encoded.tobytes()).decode("ascii")

                def show():
                    if not self.winfo_exists():
                        return
                    self.preview_image = tk.PhotoImage(data=png)
                    self.preview_label.configure(image=self.preview_image, text="")
                    self.preview_status.set(f"RTSP hoạt động • {width}×{height}")

                self.after(0, show)
            except Exception as exc:
                message = str(exc)
                self.after(0, lambda message=message: self.preview_status.set(f"Không mở được camera: {message}") if self.winfo_exists() else None)
            finally:
                if cap is not None:
                    cap.release()

        threading.Thread(target=work, daemon=True).start()

    def save(self):
        data = {key: var.get() for key, var in self.vars.items()}
        if not data["id"].strip() or not data["rtsp_url"].strip():
            messagebox.showwarning("Thiếu thông tin", "Cần nhập mã camera và địa chỉ RTSP.", parent=self)
            return
        data["reconnect_seconds"] = 3
        data["preview_width"] = 960
        self.result = data
        self.destroy()


class Manager(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Lốp Xe Server - Quản lý AI Camera")
        self.geometry("1050x650")
        self.minsize(900, 580)
        self.config_data = load_server_config()
        self.status = tk.StringVar(value="Sẵn sàng")
        self.server_name = tk.StringVar(value=self.config_data.get("server_name", "LOPXE-SERVER"))
        self.web_url = tk.StringVar(value=self.config_data.get("web_app_url", ""))
        self.api_key = tk.StringVar(value=self.config_data.get("api_key", ""))
        self.build_ui()
        self.refresh_tree()

    def build_ui(self):
        style = ttk.Style(self)
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
        header = ttk.Frame(self, padding=16)
        header.pack(fill="x")
        ttk.Label(header, text="LỐP XE SERVER", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="AI ANPR Việt Nam • nhiều camera/làn", foreground="#555").pack(side="left", padx=16)

        connection = ttk.LabelFrame(self, text="Kết nối hệ thống", padding=12)
        connection.pack(fill="x", padx=16, pady=(0, 12))
        for row, (label, variable, secret) in enumerate([
            ("Tên Server", self.server_name, False),
            ("Google Apps Script Web App URL", self.web_url, False),
            ("AI API key", self.api_key, True),
        ]):
            ttk.Label(connection, text=label, width=30).grid(row=row, column=0, sticky="w", pady=5)
            ttk.Entry(connection, textvariable=variable, show="•" if secret else "").grid(row=row, column=1, sticky="ew", pady=5)
        connection.columnconfigure(1, weight=1)
        ttk.Button(connection, text="Kiểm tra Web App", command=self.test_web).grid(row=1, column=2, padx=(10, 0))

        cameras = ttk.LabelFrame(self, text="Camera và làn dịch vụ", padding=12)
        cameras.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        self.tree = ttk.Treeview(cameras, columns=("id", "name", "lane", "rtsp", "state"), show="headings", height=11)
        widths = {"id": 120, "name": 170, "lane": 110, "rtsp": 430, "state": 90}
        titles = {"id": "Mã", "name": "Tên camera", "lane": "Làn", "rtsp": "RTSP", "state": "Trạng thái"}
        for key in self.tree["columns"]:
            self.tree.heading(key, text=titles[key]); self.tree.column(key, width=widths[key], anchor="w")
        self.tree.pack(fill="both", expand=True)
        actions = ttk.Frame(cameras)
        actions.pack(fill="x", pady=(10, 0))
        ttk.Button(actions, text="Thêm camera", command=self.add_camera).pack(side="left", padx=4)
        ttk.Button(actions, text="Sửa", command=self.edit_camera).pack(side="left", padx=4)
        ttk.Button(actions, text="Xóa", command=self.delete_camera).pack(side="left", padx=4)
        ttk.Button(actions, text="Tự dò IP camera", command=self.scan_cameras).pack(side="left", padx=16)

        footer = ttk.Frame(self, padding=(16, 0, 16, 16))
        footer.pack(fill="x")
        ttk.Label(footer, textvariable=self.status).pack(side="left")
        ttk.Button(footer, text="Mở nhật ký", command=self.open_logs).pack(side="right", padx=4)
        ttk.Button(footer, text="Dừng Server", command=self.stop_server).pack(side="right", padx=4)
        ttk.Button(footer, text="Lưu & chạy Server", command=self.save_and_start).pack(side="right", padx=4)

    def refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        for i, cam in enumerate(self.config_data.get("cameras", [])):
            self.tree.insert("", "end", iid=str(i), values=(cam.get("id"), cam.get("name"), cam.get("lane"), self.safe_rtsp(cam.get("rtsp_url", "")), "Bật" if cam.get("enabled", True) else "Tắt"))

    @staticmethod
    def safe_rtsp(url):
        text = str(url or "")
        if "@" in text and "://" in text:
            scheme, tail = text.split("://", 1)
            return f"{scheme}://***:***@{tail.split('@', 1)[1]}"
        return text

    def add_camera(self):
        dialog = CameraDialog(self)
        self.wait_window(dialog)
        if dialog.result:
            self.config_data.setdefault("cameras", []).append(dialog.result)
            self.refresh_tree()

    def selected_index(self):
        selected = self.tree.selection()
        return int(selected[0]) if selected else None

    def edit_camera(self):
        index = self.selected_index()
        if index is None:
            messagebox.showinfo("Chọn camera", "Hãy chọn camera cần sửa.")
            return
        dialog = CameraDialog(self, self.config_data["cameras"][index])
        self.wait_window(dialog)
        if dialog.result:
            self.config_data["cameras"][index] = dialog.result
            self.refresh_tree()

    def delete_camera(self):
        index = self.selected_index()
        if index is not None and messagebox.askyesno("Xóa camera", "Xóa camera đã chọn?"):
            self.config_data["cameras"].pop(index)
            self.refresh_tree()

    def collect_config(self):
        self.config_data["server_name"] = self.server_name.get().strip() or "LOPXE-SERVER"
        self.config_data["web_app_url"] = self.web_url.get().strip()
        self.config_data["api_key"] = self.api_key.get().strip()
        return self.config_data

    def test_web(self):
        url = self.web_url.get().strip()
        if not url.startswith("https://"):
            messagebox.showwarning("URL chưa đúng", "Web App URL phải bắt đầu bằng https://")
            return
        self.status.set("Đang kiểm tra Web App…")
        def work():
            try:
                with urllib.request.urlopen(url, timeout=10) as response:
                    ok = 200 <= response.status < 400
                self.after(0, lambda: self.status.set("Kết nối Web App thành công" if ok else "Web App không phản hồi đúng"))
            except Exception as exc:
                message = str(exc)
                self.after(0, lambda message=message: self.status.set(f"Không kết nối được: {message}"))
        threading.Thread(target=work, daemon=True).start()

    def save_and_start(self):
        config = self.collect_config()
        if not config.get("web_app_url") or not config.get("api_key"):
            messagebox.showwarning("Thiếu cấu hình", "Cần nhập Web App URL và AI API key.")
            return
        if not config.get("cameras"):
            messagebox.showwarning("Chưa có camera", "Hãy thêm ít nhất một camera RTSP.")
            return
        save_server_config(config)
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        (DATA_DIR / "stop.flag").write_text("RESTART", encoding="utf-8")
        self.status.set("Đang áp dụng cấu hình và khởi động lại AI…")

        def restart():
            pid_file = DATA_DIR / "service-host.pid"
            deadline = time.time() + 60
            while pid_file.exists() and time.time() < deadline:
                time.sleep(0.4)
            (DATA_DIR / "stop.flag").unlink(missing_ok=True)
            exe = APP_DIR / "LopXeServiceHost.exe"
            flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            try:
                subprocess.Popen([str(exe)], cwd=str(APP_DIR), creationflags=flags, close_fds=True)
                self.after(0, lambda: self.status.set("Server đang chạy. Máy Client có thể tự tìm trong LAN."))
            except Exception as exc:
                message = str(exc)
                self.after(0, lambda message=message: messagebox.showerror("Không chạy được Server", message))

        threading.Thread(target=restart, daemon=True).start()

    def stop_server(self):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        (DATA_DIR / "stop.flag").write_text("STOP", encoding="utf-8")
        self.status.set("Đã gửi lệnh dừng Server")

    def open_logs(self):
        path = DATA_DIR / "logs"
        path.mkdir(parents=True, exist_ok=True)
        subprocess.Popen(["explorer", str(path)])

    def scan_cameras(self):
        self.status.set("Đang dò các thiết bị mở cổng RTSP 554…")
        def check(ip):
            try:
                with socket.create_connection((ip, 554), timeout=0.18):
                    return ip
            except OSError:
                return None
        def work():
            try:
                local_ip = socket.gethostbyname(socket.gethostname())
                prefix = ".".join(local_ip.split(".")[:3])
                with ThreadPoolExecutor(max_workers=64) as pool:
                    found = [ip for ip in pool.map(check, [f"{prefix}.{i}" for i in range(1, 255)]) if ip]
                def apply():
                    existing = {str(c.get("rtsp_url", "")) for c in self.config_data.get("cameras", [])}
                    for ip in found:
                        url = f"rtsp://admin:password@{ip}:554/Streaming/Channels/101"
                        if url not in existing:
                            number = len(self.config_data.setdefault("cameras", [])) + 1
                            self.config_data["cameras"].append({"id": f"CAM-{number:02d}", "name": f"Camera {ip}", "lane": f"Làn {number}", "rtsp_url": url, "enabled": True, "preview": False})
                    self.refresh_tree()
                    self.status.set(f"Tìm thấy {len(found)} thiết bị RTSP. Hãy sửa tài khoản/mật khẩu trước khi chạy.")
                self.after(0, apply)
            except Exception as exc:
                message = str(exc)
                self.after(0, lambda message=message: self.status.set(f"Dò camera thất bại: {message}"))
        threading.Thread(target=work, daemon=True).start()


if __name__ == "__main__":
    Manager().mainloop()

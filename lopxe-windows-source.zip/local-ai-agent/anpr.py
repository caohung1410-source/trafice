from __future__ import annotations
import os, re, time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import List, Optional, Tuple, Dict
import cv2
import numpy as np

try:
    import easyocr
except Exception:
    easyocr = None

PLATE_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
CONFUSION = {"O":"0","Q":"0","D":"0","I":"1","L":"1","Z":"2","S":"5","G":"6","B":"8"}
VN_PLATE_PATTERNS = [
    re.compile(r"^[1-9]\d[A-Z]\d{4,5}$"),
    re.compile(r"^[1-9]\d[A-Z]{2}\d{4,5}$"),
    re.compile(r"^[1-9]\d\d[A-Z]\d{4,5}$"),
]

def normalize_plate(text: str) -> str:
    return re.sub(r"[^0-9A-Z]", "", str(text or "").upper())

def fix_by_position(p: str) -> str:
    p = normalize_plate(p)
    if len(p) < 7: return p
    c = list(p)
    for i in (0,1):
        if i < len(c) and c[i].isalpha() and c[i] in CONFUSION:
            c[i] = CONFUSION[c[i]]
    for i in range(max(3, len(c)-5), len(c)):
        if c[i].isalpha() and c[i] in CONFUSION:
            c[i] = CONFUSION[c[i]]
    return "".join(c)

def plausible_vn_plate(p: str) -> bool:
    p = fix_by_position(p)
    if not (7 <= len(p) <= 10) or not p[:2].isdigit(): return False
    province = int(p[:2])
    if not 11 <= province <= 99: return False
    if sum(x.isalpha() for x in p) < 1 or sum(x.isdigit() for x in p) < 6: return False
    return any(rx.match(p) for rx in VN_PLATE_PATTERNS)

def syntax_score(p: str) -> float:
    p = fix_by_position(p)
    if not plausible_vn_plate(p): return 0.0
    s = .75
    if len(p) in (8,9): s += .10
    if p[:2].isdigit(): s += .05
    if 1 <= sum(x.isalpha() for x in p[2:5]) <= 2: s += .05
    return min(.95, s)

def format_plate(p: str) -> str:
    p = fix_by_position(p)
    m = re.match(r"^(\d{2})([A-Z0-9]{1,3})(\d{4,5})$", p)
    if not m: return p
    province, series, nums = m.groups()
    if len(nums) == 5: nums = nums[:3] + "." + nums[3:]
    return f"{province}{series}-{nums}"

def edit_distance(a: str, b: str) -> int:
    a,b=normalize_plate(a),normalize_plate(b)
    prev=list(range(len(b)+1))
    for i,ca in enumerate(a,1):
        cur=[i]
        for j,cb in enumerate(b,1):
            cur.append(min(cur[-1]+1,prev[j]+1,prev[j-1]+(ca!=cb)))
        prev=cur
    return prev[-1]

@dataclass
class Candidate:
    crop: np.ndarray
    box: Tuple[int,int,int,int]
    score: float
    source: str="unknown"

class PerspectiveRectifier:
    @staticmethod
    def order_points(pts):
        pts=np.asarray(pts,dtype=np.float32).reshape(4,2)
        s=pts.sum(axis=1); d=np.diff(pts,axis=1).reshape(-1)
        return np.array([pts[np.argmin(s)],pts[np.argmin(d)],pts[np.argmax(s)],pts[np.argmax(d)]],dtype=np.float32)

    def rectify(self,crop):
        if crop is None or crop.size==0: return crop
        h,w=crop.shape[:2]
        if w<40 or h<16: return crop
        gray=cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY)
        edges=cv2.Canny(cv2.bilateralFilter(gray,7,45,45),60,180)
        cnts,_=cv2.findContours(edges,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
        best=None; area0=float(w*h)
        for c in sorted(cnts,key=cv2.contourArea,reverse=True)[:30]:
            approx=cv2.approxPolyDP(c,.025*cv2.arcLength(c,True),True)
            if len(approx)!=4: continue
            area=cv2.contourArea(approx)
            if area<area0*.18 or area>area0*.98: continue
            pts=self.order_points(approx.reshape(4,2))
            tw=max(np.linalg.norm(pts[1]-pts[0]),np.linalg.norm(pts[2]-pts[3]))
            th=max(np.linalg.norm(pts[3]-pts[0]),np.linalg.norm(pts[2]-pts[1]))
            if th<8 or not 1.0<=tw/th<=6.8: continue
            best=pts; break
        if best is None: return crop
        tw=int(max(np.linalg.norm(best[1]-best[0]),np.linalg.norm(best[2]-best[3])))
        th=int(max(np.linalg.norm(best[3]-best[0]),np.linalg.norm(best[2]-best[1])))
        tw,th=max(tw,80),max(th,28)
        dst=np.array([[0,0],[tw-1,0],[tw-1,th-1],[0,th-1]],dtype=np.float32)
        M=cv2.getPerspectiveTransform(best,dst)
        return cv2.warpPerspective(crop,M,(tw,th),flags=cv2.INTER_CUBIC,borderMode=cv2.BORDER_REPLICATE)

class OnnxPlateDetector:
    def __init__(self,path,input_size=640,conf=.32,nms=.45):
        self.path=str(path or ""); self.input_size=int(input_size); self.conf=float(conf); self.nms=float(nms)
        self.net=cv2.dnn.readNetFromONNX(self.path) if self.path and os.path.exists(self.path) else None

    @property
    def available(self): return self.net is not None

    def detect(self,frame):
        if self.net is None: return []
        H,W=frame.shape[:2]; size=self.input_size
        scale=min(size/W,size/H); nw,nh=int(round(W*scale)),int(round(H*scale))
        img=cv2.resize(frame,(nw,nh)); canvas=np.full((size,size,3),114,np.uint8)
        dx=(size-nw)//2;dy=(size-nh)//2;canvas[dy:dy+nh,dx:dx+nw]=img
        blob=cv2.dnn.blobFromImage(canvas,1/255.0,(size,size),swapRB=True,crop=False)
        self.net.setInput(blob); out=np.squeeze(np.array(self.net.forward()))
        if out.ndim!=2: return []
        if out.shape[0]<out.shape[1] and out.shape[0]<=128: out=out.T
        boxes=[];scores=[]
        for row in out:
            if len(row)<5: continue
            cx,cy,bw,bh=map(float,row[:4]); tail=np.asarray(row[4:],float)
            if len(row)==5: score=float(row[4])
            elif tail.size and np.max(tail)<=1:
                v8=float(np.max(tail)); v5=float(tail[0]*np.max(tail[1:])) if tail.size>1 else v8
                score=max(v8,v5)
            else: score=float(np.max(tail)) if tail.size else 0
            if score<self.conf: continue
            x=int(round((cx-bw/2-dx)/max(scale,1e-6))); y=int(round((cy-bh/2-dy)/max(scale,1e-6)))
            ww=int(round(bw/max(scale,1e-6))); hh=int(round(bh/max(scale,1e-6)))
            x=max(0,x);y=max(0,y);ww=min(W-x,ww);hh=min(H-y,hh)
            ratio=ww/max(1,hh)
            if ww<45 or hh<14 or not .85<=ratio<=7: continue
            boxes.append([x,y,ww,hh]);scores.append(score)
        if not boxes: return []
        idx=cv2.dnn.NMSBoxes(boxes,scores,self.conf,self.nms); result=[]
        for ii in np.array(idx).reshape(-1) if len(idx) else []:
            x,y,w,h=boxes[int(ii)];px=int(w*.10);py=int(h*.22)
            x1=max(0,x-px);y1=max(0,y-py);x2=min(W,x+w+px);y2=min(H,y+h+py)
            result.append(Candidate(frame[y1:y2,x1:x2].copy(),(x1,y1,x2-x1,y2-y1),float(scores[int(ii)]),"onnx"))
        return result

class GeometricPlateDetector:
    def detect(self,frame,max_candidates=8):
        h,w=frame.shape[:2];area0=float(h*w)
        gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        gray=cv2.bilateralFilter(gray,9,55,55)
        bh=cv2.morphologyEx(gray,cv2.MORPH_BLACKHAT,cv2.getStructuringElement(cv2.MORPH_RECT,(13,5)))
        grad=cv2.convertScaleAbs(cv2.Sobel(bh,cv2.CV_32F,1,0,ksize=3))
        _,bw=cv2.threshold(grad,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
        bw=cv2.morphologyEx(bw,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_RECT,(17,5)),iterations=2)
        cnts,_=cv2.findContours(bw,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE);out=[]
        for c in cnts:
            x,y,ww,hh=cv2.boundingRect(c);area=ww*hh;ratio=ww/max(1,hh)
            if area<area0*.00035 or area>area0*.10 or ww<42 or hh<14 or not 1<=ratio<=6.8: continue
            fill=cv2.contourArea(c)/max(1,area)
            if fill<.10: continue
            px=int(ww*.12);py=int(hh*.25);x1=max(0,x-px);y1=max(0,y-py);x2=min(w,x+ww+px);y2=min(h,y+hh+py)
            score=min(.82,.30+min(.28,fill*.45)+(.12 if 1.6<=ratio<=5.5 else .04))
            out.append(Candidate(frame[y1:y2,x1:x2].copy(),(x1,y1,x2-x1,y2-y1),score,"geometry"))
        out.sort(key=lambda c:c.score*c.box[2]*c.box[3],reverse=True)
        return out[:max_candidates]

class OCRReader:
    def __init__(self,gpu=False):
        if easyocr is None: raise RuntimeError("Thiếu EasyOCR. Chạy install.bat")
        model_dir=os.environ.get("LOPXE_EASYOCR_MODEL_DIR","").strip() or None
        allow_download=os.environ.get("LOPXE_EASYOCR_ALLOW_DOWNLOAD","").strip()=="1" or model_dir is None
        self.reader=easyocr.Reader(["en"],gpu=bool(gpu),verbose=False,
                                   model_storage_directory=model_dir,download_enabled=allow_download)

    def variants(self,crop):
        h,w=crop.shape[:2];scale=max(1.0,420.0/max(w,1))
        img=cv2.resize(crop,None,fx=scale,fy=scale,interpolation=cv2.INTER_CUBIC) if scale>1 else crop.copy()
        gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
        clahe=cv2.createCLAHE(2.3,(8,8)).apply(gray)
        blur=cv2.GaussianBlur(clahe,(0,0),1.0);sharp=cv2.addWeighted(clahe,1.7,blur,-.7,0)
        thr=cv2.adaptiveThreshold(sharp,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,31,9)
        return [("gray",clahe),("sharp",sharp),("thr",thr),("inv",255-thr)]

    def read_one(self,img):
        res=self.reader.readtext(img,detail=1,paragraph=False,allowlist=PLATE_CHARS,decoder="greedy",
                                 text_threshold=.45,low_text=.25,link_threshold=.25,contrast_ths=.05,adjust_contrast=.7)
        items=[]
        for box,text,conf in res:
            clean=normalize_plate(text)
            if clean:
                pts=np.array(box,float);items.append((float(pts[:,0].mean()),float(pts[:,1].mean()),clean,float(conf)))
        if not items:return "",0.0,0
        ys=[i[1] for i in items];two=(max(ys)-min(ys))>img.shape[0]*.18 and len(items)>=2
        if two:
            split=(max(ys)+min(ys))/2
            ordered=sorted([i for i in items if i[1]<=split],key=lambda z:z[0])+sorted([i for i in items if i[1]>split],key=lambda z:z[0])
            lines=2
        else:
            ordered=sorted(items,key=lambda z:z[0]);lines=1
        text=fix_by_position("".join(i[2] for i in ordered));total=max(1,sum(len(i[2]) for i in ordered))
        conf=sum(i[3]*len(i[2]) for i in ordered)/total
        return text,float(conf),lines

    def read(self,crop):
        reads=[]
        for name,img in self.variants(crop):
            text,conf,lines=self.read_one(img)
            if text: reads.append((text,conf,conf*(.85+.15*syntax_score(text)),name,lines))
        if not reads:return "",0.0,{}
        groups=[]
        for item in sorted(reads,key=lambda x:x[2],reverse=True):
            for g in groups:
                if edit_distance(item[0],g[0][0])<=1:g.append(item);break
            else:groups.append([item])
        groups.sort(key=lambda g:(len(g),sum(x[2] for x in g)),reverse=True)
        g=groups[0];g.sort(key=lambda x:(plausible_vn_plate(x[0]),x[2]),reverse=True);best=g[0]
        return best[0],min(.999,best[1]+min(.10,.025*(len(g)-1))),{"variant":best[3],"lines":best[4],"agreements":len(g)}

class ANPREngine:
    def __init__(self,cfg):
        ai=cfg.get("ai",{}); path=str(ai.get("detector_onnx","models/license_plate_detector.onnx"))
        if path and not os.path.isabs(path): path=os.path.join(os.path.dirname(__file__),path)
        self.min_ocr=float(ai.get("min_ocr_confidence",.42));self.min_plate=float(ai.get("min_plate_confidence",.68))
        self.max_candidates=int(ai.get("max_candidates_per_frame",6))
        self.detector=OnnxPlateDetector(path,ai.get("detector_input_size",640),ai.get("detector_confidence",.32),ai.get("nms_threshold",.45))
        self.geo=GeometricPlateDetector();self.rect=PerspectiveRectifier();self.ocr=OCRReader(bool(ai.get("gpu",False)))
        self.use_geo=bool(ai.get("fallback_geometric_detector",True))

    def infer(self,frame):
        cands=self.detector.detect(frame) if self.detector.available else []
        if self.use_geo and len(cands)<2:cands.extend(self.geo.detect(frame,self.max_candidates))
        unique=[]
        for c in sorted(cands,key=lambda x:x.score,reverse=True):
            x,y,w,h=c.box;cx,cy=x+w/2,y+h/2
            if any(abs(cx-(u.box[0]+u.box[2]/2))<max(w,u.box[2])*.28 and abs(cy-(u.box[1]+u.box[3]/2))<max(h,u.box[3])*.35 for u in unique):continue
            unique.append(c)
            if len(unique)>=self.max_candidates:break
        best=None
        for c in unique:
            rect=self.rect.rectify(c.crop);text,ocr_conf,meta=self.ocr.read(rect);norm=fix_by_position(text)
            if ocr_conf<self.min_ocr or not plausible_vn_plate(norm):continue
            synt=syntax_score(norm);combined=min(.999,.62*ocr_conf+.23*c.score+.15*synt)
            if combined<self.min_plate:continue
            item={"plate":format_plate(norm),"normalized":norm,"confidence":combined,"ocr_confidence":ocr_conf,
                  "detector_confidence":float(c.score),"syntax_score":synt,"candidate":c,"crop":rect,"source":c.source,"ocr_meta":meta}
            if best is None or item["confidence"]>best["confidence"]:best=item
        return best,unique

class PlateVoter:
    def __init__(self,window_seconds=2.5,min_hits=3,min_ratio=.55,max_edit_distance=1):
        self.window=float(window_seconds);self.min_hits=int(min_hits);self.min_ratio=float(min_ratio);self.max_edit=int(max_edit_distance);self.items=deque()

    def add(self,plate,confidence,crop,meta=None):
        now=time.time();key=fix_by_position(plate)
        if not plausible_vn_plate(key):return None
        self.items.append((now,key,float(confidence),crop.copy() if crop is not None else None,meta or {}))
        while self.items and now-self.items[0][0]>self.window:self.items.popleft()
        if len(self.items)<self.min_hits:return None
        scores={}
        for _,p,conf,_,_ in self.items:
            scores[p]=scores.get(p,0)+conf
            for _,q,qc,_,_ in self.items:
                if p!=q and edit_distance(p,q)<=self.max_edit:scores[p]+=qc*.30
        top=max(scores,key=scores.get);matches=[x for x in self.items if edit_distance(x[1],top)<=self.max_edit]
        ratio=len(matches)/max(1,len(self.items))
        if len(matches)<self.min_hits or ratio<self.min_ratio:return None
        exact=defaultdict(float)
        for x in matches:exact[x[1]]+=x[2]
        chosen=max(exact,key=exact.get);cm=[x for x in matches if x[1]==chosen];best=max(cm,key=lambda x:x[2])
        conf=min(.999,sum(x[2] for x in cm)/len(cm)+min(.06,.012*(len(cm)-1)))
        self.items.clear()
        return format_plate(chosen),float(conf),best[3],{"hits":len(matches),"ratio":ratio,"exactHits":len(cm),"normalized":chosen,**best[4]}

function FIX_DATABASE_TIMEZONE() {
  const id = PropertiesService.getScriptProperties().getProperty('DATABASE_ID');
  if (!id) throw new Error('Chưa có DATABASE_ID.');

  const ss = SpreadsheetApp.openById(id);
  ss.setSpreadsheetTimeZone(APP.TZ);

  console.log('Database: ' + ss.getName());
  console.log('Timezone mới: ' + ss.getSpreadsheetTimeZone());

  return {
    ok: true,
    databaseId: id,
    name: ss.getName(),
    timezone: ss.getSpreadsheetTimeZone()
  };
}

function TEST_BOOT_DATABASE() {
  const result = {
    settings: settingsMap_(),
    employees: listObjects_(APP.SHEETS.EMPLOYEES),
    serviceTypes: listObjects_(APP.SHEETS.SERVICE_TYPES),
    prices: listObjects_(APP.SHEETS.PRICE_LIST),
    cameras: listObjects_(APP.SHEETS.CAMERAS)
  };

  // Nếu dòng này log được JSON đầy đủ thì Date đã được chuẩn hóa.
  console.log(JSON.stringify(result));
  return result;
}

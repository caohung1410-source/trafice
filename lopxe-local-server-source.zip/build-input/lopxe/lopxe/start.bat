@echo off
title MAY CHU LOP XE PRO
cd /d C:\lopxe
"%LocalAppData%\Programs\Python\Python311\python.exe" -m uvicorn server:app --host 0.0.0.0 --port 8000 --reload
pause
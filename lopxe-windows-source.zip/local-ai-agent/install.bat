@echo off
setlocal
cd /d %~dp0
where py >nul 2>nul
if errorlevel 1 (
  echo Chua co Python. Hay cai Python 3.11 64-bit truoc.
  pause
  exit /b 1
)
py -3.11 -m venv .venv
if errorlevel 1 py -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist config.yaml copy config.example.yaml config.yaml
echo.
echo Cai dat xong. Sua config.yaml roi chay run.bat
pause

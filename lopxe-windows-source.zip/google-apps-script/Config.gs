const APP = Object.freeze({
  NAME: 'Lốp Xe Pro',
  VERSION: '1.4.1',
  TZ: 'Asia/Ho_Chi_Minh',

  ROLES: {
    ADMIN: 'ADMIN',
    ACCOUNTING: 'ACCOUNTING',
    TECH: 'TECH'
  },

  ROLE_LABELS: {
    ADMIN: 'Quản lý',
    ACCOUNTING: 'Kế toán',
    TECH: 'Kỹ thuật'
  },

  SHEETS: {
    SETTINGS: 'SETTINGS',
    EMPLOYEES: 'EMPLOYEES',
    SERVICES: 'SERVICES',
    LANES: 'LANES',
    CAMERAS: 'CAMERAS',
    JOBS: 'JOBS',
    PLATE_EVENTS: 'PLATE_EVENTS',
    AGENTS: 'AGENTS'
  },

  HEADERS: {
    SETTINGS: ['key','value','description','updatedAt'],
    EMPLOYEES: ['id','name','phone','role','active','createdAt','updatedAt'],
    SERVICES: ['id','name','description','defaultPrice','active','createdAt','updatedAt'],
    LANES: ['id','name','cameraCount','active','createdAt','updatedAt'],
    CAMERAS: ['id','laneId','laneName','cameraNo','name','model','rtspUrl','location','enabled','createdAt','updatedAt'],
    JOBS: [
      'id','ticketNo','createdAt','serviceDate','plate','customer','phone','vehicleType',
      'laneId','laneName','employeeId','employeeName',
      'serviceItemsJson','serviceSummary','amount',
      'status','startedAt','completedAt','closedAt','closedBy',
      'note','techNote','imageUrl','source',
      'paymentStatus','paymentMethod','paidAt',
      'inventoryConfirmed','inventoryConfirmedAt','inventoryConfirmedBy',
      'accountingNote'
    ],
    PLATE_EVENTS: ['id','timestamp','cameraId','cameraName','plate','confidence','imageUrl','rawJson','used'],
    AGENTS: ['id','name','cameraId','lastSeen','status','version','ip','fps','lastPlate','message','updatedAt']
  },

  STATUS: {
    RECEIVED: 'Chờ tiếp nhận',
    WORKING: 'Đang làm',
    TECH_DONE: 'KT đã hoàn thành',
    CLOSED: 'Đã giao xe',
    CANCELLED: 'Đã hủy'
  },

  PAYMENT: {
    UNPAID: 'Chưa thu',
    PAID: 'Đã thu'
  },

  SESSION_TTL: 21600,
  AGENT_OFFLINE_SECONDS: 90
});

function nowIso_() {
  return Utilities.formatDate(new Date(), APP.TZ, "yyyy-MM-dd'T'HH:mm:ss");
}

function today_() {
  return Utilities.formatDate(new Date(), APP.TZ, 'yyyy-MM-dd');
}

function asBool_(v) {
  return v === true || String(v).toLowerCase() === 'true' || String(v) === '1';
}

function safeNumber_(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function newId_(prefix) {
  return prefix + '_' + Utilities.getUuid().replace(/-/g, '').slice(0, 16);
}

function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function normalizeRole_(role) {
  const r = String(role || '').trim().toUpperCase();
  if (r === APP.ROLES.ACCOUNTING) return APP.ROLES.ACCOUNTING;
  if (r === APP.ROLES.TECH) return APP.ROLES.TECH;
  return APP.ROLES.ADMIN;
}

function roleLabel_(role) {
  return APP.ROLE_LABELS[normalizeRole_(role)] || 'Quản lý';
}

function normalizePlate_(plate) {
  return String(plate || '')
    .toUpperCase()
    .replace(/\s+/g, '')
    .replace(/[^0-9A-Z.-]/g, '');
}

function formatTimeHm_(iso) {
  if (!iso) return '';
  try { return Utilities.formatDate(new Date(iso), APP.TZ, 'HH:mm'); } catch (e) { return ''; }
}

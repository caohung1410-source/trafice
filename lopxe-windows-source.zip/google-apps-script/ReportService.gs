function resolveReportRange_(filters) {
  filters = filters || {};
  let from = String(filters.from || '');
  let to = String(filters.to || '');
  if (filters.mode === 'day' && filters.date) { from = to = String(filters.date); }
  else if (filters.mode === 'month' && filters.month) {
    const parts = String(filters.month).split('-');
    const y = Number(parts[0]);
    const m = Number(parts[1]);
    const last = new Date(y, m, 0).getDate();
    from = `${y}-${('0'+m).slice(-2)}-01`;
    to = `${y}-${('0'+m).slice(-2)}-${('0'+last).slice(-2)}`;
  } else if (filters.mode === 'year' && filters.year) {
    from = `${filters.year}-01-01`;
    to = `${filters.year}-12-31`;
  }
  return { from, to };
}

function buildReport_(rows) {
  const laneMap = {};
  const empMap = {};
  rows.forEach(x => {
    const lk = x.laneName || 'Chưa gán làn';
    if (!laneMap[lk]) laneMap[lk] = { laneName:lk, count:0, revenue:0 };
    laneMap[lk].count += 1; laneMap[lk].revenue += safeNumber_(x.amount);
    const ek = x.employeeName || 'Chưa gán';
    if (!empMap[ek]) empMap[ek] = { employeeName:ek, count:0, revenue:0 };
    empMap[ek].count += 1; empMap[ek].revenue += safeNumber_(x.amount);
  });
  return {
    totalRows: rows.length,
    totalDone: rows.filter(x => x.status === APP.STATUS.CLOSED).length,
    totalRevenue: rows.filter(x => x.status === APP.STATUS.CLOSED).reduce((s,x)=>s + safeNumber_(x.amount),0),
    totalUnpaid: rows.filter(x => x.status !== APP.STATUS.CLOSED).length,
    byLane:Object.values(laneMap).sort((a,b)=>b.revenue - a.revenue),
    byEmployee:Object.values(empMap).sort((a,b)=>b.revenue - a.revenue),
    rows: rows.sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)))
  };
}

function apiManagerReport(token, filters) {
  requireRole_(token, APP.ROLES.ADMIN);
  const range = resolveReportRange_(filters);
  let rows = listObjects_(APP.SHEETS.JOBS).map(jobToClient_);
  if (range.from) rows = rows.filter(x => String(x.serviceDate) >= range.from);
  if (range.to) rows = rows.filter(x => String(x.serviceDate) <= range.to);
  const rpt = buildReport_(rows);
  return Object.assign({ from:range.from, to:range.to }, rpt);
}

function apiAccountingReport(token, filters) {
  requireRole_(token, [APP.ROLES.ADMIN, APP.ROLES.ACCOUNTING]);
  const range = resolveReportRange_(filters);
  let rows = listObjects_(APP.SHEETS.JOBS).map(jobToClient_);
  if (range.from) rows = rows.filter(x => String(x.serviceDate) >= range.from);
  if (range.to) rows = rows.filter(x => String(x.serviceDate) <= range.to);
  const rpt = buildReport_(rows);
  return Object.assign({ from:range.from, to:range.to }, rpt);
}

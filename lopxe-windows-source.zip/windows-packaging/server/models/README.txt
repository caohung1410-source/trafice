Thư mục model AI cài tại C:\ProgramData\LopXePro\models

- easyocr\ chứa model OCR đã đóng gói để chạy offline.
- license_plate_detector.onnx là model detector biển số chuyên dụng tùy chọn.

Nếu chưa có license_plate_detector.onnx, phần mềm vẫn chạy detector hình học dự phòng.
Để đạt độ chính xác vận hành cao, cần hiệu chỉnh bằng ảnh thật từ từng camera/làn.

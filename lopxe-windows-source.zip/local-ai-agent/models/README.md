# Detector biển số Việt Nam

Đặt model ONNX 1 class tại:
`models/license_plate_detector.onnx`

Khuyến nghị model YOLOv8/YOLO11 custom, input 640x640, class duy nhất `license_plate`.

Không có model vẫn chạy bằng detector hình học để thử nghiệm, nhưng production nên dùng ONNX chuyên biển số.

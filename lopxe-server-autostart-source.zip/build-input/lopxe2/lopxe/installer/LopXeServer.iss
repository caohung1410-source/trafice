#define AppName "Lốp Xe Pro Server"
#define AppVersion "1.1.0"

[Setup]
AppId={{9FCE70B5-2C72-405A-9821-2A7A258DB52D}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName={autopf}\Lop Xe Pro Server
DefaultGroupName={#AppName}
OutputDir=output
OutputBaseFilename=LopXe_Server_Setup_1.1.0
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\LopXeServer.exe

[Files]
Source: "output\server\*"; Excludes: "easyocr-models\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "output\server\easyocr-models\*"; DestDir: "{commonappdata}\LopXePro\easyocr-models"; Flags: ignoreversion recursesubdirs createallsubdirs onlyifdoesntexist

[Dirs]
Name: "{commonappdata}\LopXePro"; Permissions: users-modify
Name: "{commonappdata}\LopXePro\easyocr-models"; Permissions: users-modify

[Icons]
Name: "{group}\Mở Lốp Xe Pro"; Filename: "{app}\LopXeServer.exe"
Name: "{autodesktop}\Lốp Xe Pro"; Filename: "{app}\LopXeServer.exe"

[Run]
Filename: "netsh"; Parameters: "advfirewall firewall add rule name=""Lop Xe Pro Server"" dir=in action=allow protocol=TCP localport=8000"; Flags: runhidden
Filename: "schtasks"; Parameters: "/Create /TN ""LopXePro Server"" /TR """"{app}\LopXeServer.exe"" --background"" /SC ONSTART /RU SYSTEM /RL HIGHEST /F"; Flags: runhidden
Filename: "{app}\LopXeServer.exe"; Description: "Mở Lốp Xe Pro Server"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "schtasks"; Parameters: "/Delete /TN ""LopXePro Server"" /F"; Flags: runhidden
Filename: "taskkill"; Parameters: "/F /IM LopXeServer.exe"; Flags: runhidden

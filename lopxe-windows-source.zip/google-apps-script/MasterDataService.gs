function activeEmployees_() { return listObjects_(APP.SHEETS.EMPLOYEES).filter(x => asBool_(x.active)); }
function activeServices_() { return listObjects_(APP.SHEETS.SERVICES).filter(x => asBool_(x.active)); }
function activeLanes_() { return listObjects_(APP.SHEETS.LANES).filter(x => asBool_(x.active)); }

function serviceToClient_(x) {
  return { id:x.id, name:x.name, description:x.description || '', defaultPrice:safeNumber_(x.defaultPrice), active:asBool_(x.active) };
}

function laneCameraMap_() {
  const map = {};
  listObjects_(APP.SHEETS.CAMERAS).forEach(c => {
    const k = String(c.laneId || '');
    if (!map[k]) map[k] = [];
    map[k].push({ id:c.id, cameraNo:safeNumber_(c.cameraNo), name:c.name, model:c.model || '', rtspUrl:c.rtspUrl || '', enabled:asBool_(c.enabled) });
  });
  Object.keys(map).forEach(k => map[k].sort((a,b)=>a.cameraNo - b.cameraNo));
  return map;
}

function apiBootstrap(token) {
  const session = requireSession_(token);
  const services = activeServices_().map(serviceToClient_);
  const lanes = activeLanes_();
  const cameras = listObjects_(APP.SHEETS.CAMERAS).filter(x => asBool_(x.enabled));
  return {
    ok:true,
    app:APP.NAME,
    version:APP.VERSION,
    role:session.role,
    roleLabel:roleLabel_(session.role),
    settings:settingsMap_(),
    statuses:APP.STATUS,
    payment:APP.PAYMENT,
    today:today_(),
    employees:activeEmployees_(),
    services:services,
    lanes:lanes,
    laneCameras:laneCameraMap_(),
    cameraCount:cameras.length,
    notifyEnabled:false
  };
}

function apiListEmployees(token) { requireRole_(token, APP.ROLES.ADMIN); return listObjects_(APP.SHEETS.EMPLOYEES); }
function apiSaveEmployee(token, data) {
  requireRole_(token, APP.ROLES.ADMIN);
  data = data || {};
  const name = String(data.name || '').trim();
  if (!name) throw new Error('Nhập họ tên nhân viên.');
  const patch = { name, phone:String(data.phone || '').trim(), role:String(data.role || 'Kỹ thuật').trim(), active:data.active !== false };
  if (data.id) return updateById_(APP.SHEETS.EMPLOYEES, data.id, patch);
  return appendObject_(APP.SHEETS.EMPLOYEES, Object.assign({ id:newId_('NV'), createdAt:nowIso_(), updatedAt:nowIso_() }, patch));
}
function apiDeleteEmployee(token, id) { requireRole_(token, APP.ROLES.ADMIN); return deleteById_(APP.SHEETS.EMPLOYEES, id); }

function apiListServices(token) { requireSession_(token); return listObjects_(APP.SHEETS.SERVICES); }
function apiSaveService(token, data) {
  requireRole_(token, APP.ROLES.ADMIN);
  data = data || {};
  const name = String(data.name || '').trim();
  if (!name) throw new Error('Nhập tên dịch vụ.');
  const patch = { name, description:String(data.description || '').trim(), defaultPrice:Math.max(0, safeNumber_(data.defaultPrice)), active:data.active !== false };
  if (data.id) return updateById_(APP.SHEETS.SERVICES, data.id, patch);
  return appendObject_(APP.SHEETS.SERVICES, Object.assign({ id:newId_('DV'), createdAt:nowIso_(), updatedAt:nowIso_() }, patch));
}
function apiDeleteService(token, id) { requireRole_(token, APP.ROLES.ADMIN); return deleteById_(APP.SHEETS.SERVICES, id); }

function apiListLanes(token) {
  requireRole_(token, APP.ROLES.ADMIN);
  const map = laneCameraMap_();
  return listObjects_(APP.SHEETS.LANES).map(x => Object.assign({}, x, { cameras: map[x.id] || [] }));
}

function apiSaveLane(token, data) {
  requireRole_(token, APP.ROLES.ADMIN);
  data = data || {};
  const name = String(data.name || '').trim();
  if (!name) throw new Error('Nhập tên làn.');
  const patch = { name, cameraCount: Math.max(0, safeNumber_(data.cameraCount || 0)), active:data.active !== false };
  let saved;
  if (data.id) saved = updateById_(APP.SHEETS.LANES, data.id, patch);
  else saved = appendObject_(APP.SHEETS.LANES, Object.assign({ id:newId_('LANE'), createdAt:nowIso_(), updatedAt:nowIso_() }, patch));
  syncLaneCameras_(saved.id);
  return saved;
}

function apiDeleteLane(token, id) {
  requireRole_(token, APP.ROLES.ADMIN);
  listObjects_(APP.SHEETS.CAMERAS).filter(x => String(x.laneId) === String(id)).forEach(x => deleteById_(APP.SHEETS.CAMERAS, x.id));
  return deleteById_(APP.SHEETS.LANES, id);
}

function apiSaveCamera(token, data) {
  requireRole_(token, APP.ROLES.ADMIN);
  data = data || {};
  const camera = getByField_(APP.SHEETS.CAMERAS, 'id', data.id);
  if (!camera) throw new Error('Không tìm thấy camera.');
  return updateById_(APP.SHEETS.CAMERAS, camera.id, {
    model:String(data.model || '').trim(),
    rtspUrl:String(data.rtspUrl || '').trim(),
    enabled:data.enabled !== false,
    laneName:camera.laneName,
    location:camera.laneName
  });
}

function apiSaveSettings(token, data) {
  requireRole_(token, APP.ROLES.ADMIN);
  ['SHOP_NAME','SHOP_PHONE','SHOP_ADDRESS','TICKET_PREFIX','AUTO_REFRESH_SECONDS','AGENT_REFRESH_SECONDS','AGENT_OFFLINE_SECONDS'].forEach(k => {
    if (data && data[k] !== undefined) upsertSetting_(k, data[k], '');
  });
  return settingsMap_();
}

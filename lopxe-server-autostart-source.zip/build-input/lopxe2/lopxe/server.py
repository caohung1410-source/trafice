import asyncio
import json
import sqlite3
import os
import io
from datetime import datetime
from typing import List, Optional

import cv2
import numpy as np
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
import gspread
from google.oauth2.service_account import Credentials

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, UploadFile, File, Response, Query
from fastapi.responses import HTMLResponse, FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel

from database import get_db, init_db, DB_PATH
from ai_engine import read_plate_from_image
from camera_service import camera_mgr

init_db()
app = FastAPI(title="LỐP XE PRO")
APP_DIR = os.path.dirname(__file__)
DATA_DIR = os.environ.get("LOPXE_DATA_DIR", APP_DIR)
os.makedirs(DATA_DIR, exist_ok=True)

STATIC_DIR = os.path.join(DATA_DIR, "static")
os.makedirs(os.path.join(STATIC_DIR, "snapshots"), exist_ok=True)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

SYNC_CONFIG_PATH = os.path.join(DATA_DIR, "sync_config.json")
CREDS_PATH = os.path.join(DATA_DIR, "credentials.json")

class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active_connections.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self.active_connections:
            self.active_connections.remove(ws)

    async def broadcast(self, message: dict):
        for conn in self.active_connections:
            try:
                await conn.send_text(json.dumps(message))
            except Exception:
                pass

ws_manager = ConnectionManager()

def broadcast_sync(msg):
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            asyncio.run_coroutine_thread_threadsafe(ws_manager.broadcast(msg), loop)
    except Exception:
        pass

camera_mgr.set_broadcaster(broadcast_sync)

@app.on_event("startup")
def startup_event():
    camera_mgr.start_all()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)

# Models
class LoginReq(BaseModel):
    username: str
    password: str

class ChangePassReq(BaseModel):
    user_id: int
    old_password: str
    new_password: str

class TicketCreateReq(BaseModel):
    lane_id: int
    plate_number: str
    plate_image_path: Optional[str] = ""

class TechUpdateReq(BaseModel):
    technician_id: int
    lane_id: int
    plate_number: str
    service_names: str
    total_amount: float

class CashierCompleteReq(BaseModel):
    is_stock_exported: bool
    is_paid: bool

class SheetUrlReq(BaseModel):
    sheet_url: str

class BillTemplateReq(BaseModel):
    shop_name: str
    address: str
    phone: str
    footer_note: str
    paper_size: str
    show_plate_img: int
    show_bank_qr: int
    bank_account: Optional[str] = ""
    bank_name: Optional[str] = ""

# API Mẫu In Bill
@app.get("/api/bill-template")
def get_bill_template():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM bill_templates WHERE id = 1")
    row = cur.fetchone()
    conn.close()
    if row: return dict(row)
    return {
        "shop_name": "TRUNG TÂM DỊCH VỤ LỐP XE PRO",
        "address": "TP. Pleiku, Gia Lai",
        "phone": "0905.xxx.xxx",
        "footer_note": "Cảm ơn Quý khách & Hẹn gặp lại!",
        "paper_size": "K80",
        "show_plate_img": 1,
        "show_bank_qr": 0,
        "bank_account": "",
        "bank_name": ""
    }

@app.post("/api/bill-template")
def save_bill_template(req: BillTemplateReq):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        UPDATE bill_templates 
        SET shop_name = ?, address = ?, phone = ?, footer_note = ?, 
            paper_size = ?, show_plate_img = ?, show_bank_qr = ?, 
            bank_account = ?, bank_name = ?
        WHERE id = 1
    """, (req.shop_name, req.address, req.phone, req.footer_note, 
          req.paper_size, req.show_plate_img, req.show_bank_qr, 
          req.bank_account, req.bank_name))
    conn.commit()
    conn.close()
    return {"status": "success"}

# Auth & Pass
@app.post("/api/login")
def login(req: LoginReq):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, username, fullname, role FROM users WHERE username = ? AND password = ?", (req.username, req.password))
    u = cur.fetchone()
    conn.close()
    if not u:
        raise HTTPException(status_code=401, detail="Sai tài khoản hoặc mật khẩu!")
    return {"id": u["id"], "username": u["username"], "fullname": u["fullname"], "role": u["role"]}

@app.post("/api/change-password")
def change_password(req: ChangePassReq):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id FROM users WHERE id = ? AND password = ?", (req.user_id, req.old_password))
    if not cur.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="Mật khẩu cũ không chính xác!")
    cur.execute("UPDATE users SET password = ? WHERE id = ?", (req.new_password, req.user_id))
    conn.commit()
    conn.close()
    return {"status": "success", "message": "Đổi mật khẩu thành công!"}

# KPI Stats (Chuẩn múi giờ VN +7)
@app.get("/api/stats")
def get_stats():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM tickets WHERE status != 'HOAN_TAT'")
    at_workshop = cur.fetchone()[0] or 0

    cur.execute("SELECT COUNT(*) FROM tickets WHERE status = 'DANG_LAM'")
    working = cur.fetchone()[0] or 0

    cur.execute("SELECT COUNT(*) FROM tickets WHERE status IN ('CHO_TIEP_NHAN', 'CHO_THANH_TOAN')")
    pending = cur.fetchone()[0] or 0

    cur.execute("""
        SELECT COALESCE(SUM(total_amount), 0) 
        FROM tickets 
        WHERE status = 'HOAN_TAT' 
          AND date(completed_at, '+7 hours') = date('now', '+7 hours')
    """)
    revenue = cur.fetchone()[0] or 0.0
    conn.close()
    return {
        "at_workshop": at_workshop,
        "working": working,
        "pending": pending,
        "revenue": revenue
    }

# Tickets
@app.get("/api/tickets")
def get_tickets():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT t.id, t.lane_id, l.name as lane_name, t.plate_number, t.plate_image_path,
               t.technician_id, e.name as tech_name, t.status, t.total_amount, 
               t.is_stock_exported, t.is_paid, t.notes as service_names,
               strftime('%H:%M', datetime(t.created_at, '+7 hours')) as time_str,
               datetime(t.created_at, '+7 hours') as created_at_vn
        FROM tickets t
        LEFT JOIN lanes l ON t.lane_id = l.id
        LEFT JOIN employees e ON t.technician_id = e.id
        WHERE t.status != 'HOAN_TAT'
        ORDER BY t.id DESC
    """)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows

# Thêm xe thủ công (Bảo vệ lỗi kiểu dữ liệu & lưu kèm ảnh capcut)
@app.post("/api/tickets")
async def create_ticket(req: TicketCreateReq):
    plate = req.plate_number.strip().upper()
    if not plate:
        raise HTTPException(status_code=400, detail="Vui lòng nhập biển số xe!")
    
    conn = get_db()
    cur = conn.cursor()
    try:
        try:
            lane_id = int(req.lane_id)
        except Exception:
            lane_id = 1

        cur.execute("SELECT id FROM lanes WHERE id = ?", (lane_id,))
        if not cur.fetchone():
            cur.execute("SELECT id FROM lanes LIMIT 1")
            row = cur.fetchone()
            lane_id = row[0] if row else 1

        cur.execute("SELECT id FROM tickets WHERE plate_number = ? AND status != 'HOAN_TAT'", (plate,))
        if cur.fetchone():
            raise HTTPException(status_code=400, detail=f"Xe {plate} hiện đang có trong xưởng!")

        cur.execute("""
            INSERT INTO tickets (lane_id, plate_number, plate_image_path, status, total_amount, is_stock_exported, is_paid) 
            VALUES (?, ?, ?, 'CHO_TIEP_NHAN', 0, 0, 0)
        """, (lane_id, plate, req.plate_image_path or ""))
        
        tid = cur.lastrowid
        conn.commit()
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        print(f"[ERROR create_ticket]: {e}")
        raise HTTPException(status_code=500, detail=f"Lỗi cơ sở dữ liệu: {str(e)}")
    finally:
        conn.close()

    await ws_manager.broadcast({"event": "NEW_TICKET", "ticket_id": tid})
    return {"id": tid, "status": "success"}

# BƯỚC 1 -> BƯỚC 2: Kỹ thuật bấm nhận xe
@app.post("/api/tickets/{ticket_id}/tech-accept")
async def tech_accept(ticket_id: int):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE tickets SET status = 'DANG_LAM' WHERE id = ?", (ticket_id,))
    conn.commit()
    conn.close()
    await ws_manager.broadcast({"event": "TICKET_UPDATED", "ticket_id": ticket_id})
    return {"status": "success"}

# API 1: Kỹ thuật Lưu thông tin dịch vụ (VẪN GIỮ NGUYÊN TRẠNG THÁI 'DANG_LAM')
@app.put("/api/tickets/{ticket_id}/tech-update")
async def tech_update(ticket_id: int, req: TechUpdateReq):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        UPDATE tickets 
        SET technician_id = ?, lane_id = ?, plate_number = ?, notes = ?, total_amount = ?
        WHERE id = ?
    """, (req.technician_id, req.lane_id, req.plate_number, req.service_names, req.total_amount, ticket_id))
    conn.commit()
    conn.close()
    await ws_manager.broadcast({"event": "TICKET_UPDATED", "ticket_id": ticket_id})
    return {"status": "success", "message": "Đã lưu dịch vụ, xe vẫn đang làm!"}

# API 2: Khi xe thực sự làm xong ngoài xưởng mới bấm nút Báo hoàn thành (Chuyển sang 'CHO_THANH_TOAN')
@app.post("/api/tickets/{ticket_id}/tech-finish")
async def tech_finish(ticket_id: int):
    conn = get_db()
    cur = conn.cursor()
    # Kiểm tra xem xe đã có thợ hoặc dịch vụ chưa
    cur.execute("SELECT notes, technician_id FROM tickets WHERE id = ?", (ticket_id,))
    t = cur.fetchone()
    if not t or not t["notes"] or not t["technician_id"]:
        conn.close()
        raise HTTPException(status_code=400, detail="Vui lòng nhập Thợ và Dịch vụ trước khi báo hoàn thành!")

    cur.execute("UPDATE tickets SET status = 'CHO_THANH_TOAN' WHERE id = ?", (ticket_id,))
    conn.commit()
    conn.close()
    await ws_manager.broadcast({"event": "TICKET_UPDATED", "ticket_id": ticket_id})
    return {"status": "success", "message": "Đã chuyển sang kế toán thu tiền!"}

# Kế toán hoàn tất vé
@app.post("/api/tickets/{ticket_id}/cashier-complete")
async def cashier_complete(ticket_id: int, req: CashierCompleteReq):
    if not req.is_stock_exported or not req.is_paid:
        raise HTTPException(status_code=400, detail="Phải xác nhận Xuất kho và Thu tiền!")
    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE tickets SET status = 'HOAN_TAT', is_stock_exported = 1, is_paid = 1, completed_at = CURRENT_TIMESTAMP WHERE id = ?", (ticket_id,))
    conn.commit()
    conn.close()
    await ws_manager.broadcast({"event": "TICKET_FINISHED", "ticket_id": ticket_id})
    return {"status": "success"}

# Catalog
@app.get("/api/catalog")
def get_catalog():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, name, phone FROM employees WHERE active = 1")
    employees = [dict(r) for r in cur.fetchall()]
    cur.execute("SELECT id, name, price FROM services WHERE active = 1")
    services = [dict(r) for r in cur.fetchall()]
    cur.execute("SELECT id, name FROM lanes")
    lanes = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"employees": employees, "services": services, "lanes": lanes}

@app.post("/api/employees")
def add_employee(name: str):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO employees (name) VALUES (?)", (name,))
    conn.commit()
    conn.close()
    return {"status": "success"}

@app.delete("/api/employees/{emp_id}")
def delete_employee(emp_id: int):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM employees WHERE id = ?", (emp_id,))
    conn.commit()
    conn.close()
    return {"status": "success"}

@app.post("/api/services")
def add_service(name: str, price: float):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO services (name, price) VALUES (?, ?)", (name, price))
    conn.commit()
    conn.close()
    return {"status": "success"}

@app.delete("/api/services/{service_id}")
def delete_service(service_id: int):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM services WHERE id = ?", (service_id,))
    conn.commit()
    conn.close()
    return {"status": "success"}

# Làn & Camera
@app.get("/api/lanes-cameras")
def get_lanes_cameras():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, name FROM lanes")
    lanes = [dict(r) for r in cur.fetchall()]
    for l in lanes:
        cur.execute("SELECT id, name, model, rtsp_url FROM cameras WHERE lane_id = ?", (l["id"],))
        l["cameras"] = [dict(c) for c in cur.fetchall()]
    conn.close()
    return lanes

@app.post("/api/lanes")
def add_lane(name: str):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO lanes (name) VALUES (?)", (name,))
    conn.commit()
    conn.close()
    return {"status": "success"}

@app.delete("/api/lanes/{lane_id}")
def delete_lane(lane_id: int):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM cameras WHERE lane_id = ?", (lane_id,))
    cur.execute("DELETE FROM lanes WHERE id = ?", (lane_id,))
    conn.commit()
    conn.close()
    return {"status": "success"}

@app.post("/api/cameras")
def save_camera(lane_id: int, model: str, rtsp_url: str):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO cameras (lane_id, name, model, rtsp_url) VALUES (?, 'Camera', ?, ?)", (lane_id, model, rtsp_url))
    cam_id = cur.lastrowid
    conn.commit()
    conn.close()
    camera_mgr.start_cam(cam_id, lane_id, rtsp_url)
    return {"status": "success"}

@app.get("/api/camera-snapshot/{cam_id}")
def camera_snapshot(cam_id: int):
    frame = camera_mgr.last_frames.get(cam_id)
    if frame:
        return Response(content=frame, media_type="image/jpeg")
    return Response(content=b"", status_code=404)

@app.post("/api/ai/scan-plate")
async def scan_plate(file: UploadFile = File(...)):
    contents = await file.read()
    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    plate, crop_path = await run_in_threadpool(read_plate_from_image, img, True)
    return {"success": bool(plate), "plate": plate, "crop_path": crop_path}

# Google Sheets Sync
def extract_sheet_id(url_or_id: str) -> str:
    url_or_id = url_or_id.strip()
    if "/d/" in url_or_id:
        return url_or_id.split("/d/")[1].split("/")[0]
    return url_or_id

@app.get("/api/sheets/config")
def get_sheets_config():
    cfg = {"sheet_url": "", "has_creds": os.path.exists(CREDS_PATH)}
    if os.path.exists(SYNC_CONFIG_PATH):
        try:
            with open(SYNC_CONFIG_PATH, "r", encoding="utf-8") as f:
                d = json.load(f)
                cfg["sheet_url"] = d.get("SHEET_URL", "")
        except Exception:
            pass
    return cfg

@app.post("/api/sheets/save-url")
def save_sheet_url(req: SheetUrlReq):
    sheet_id = extract_sheet_id(req.sheet_url)
    data = {"SHEET_URL": req.sheet_url.strip(), "SHEET_ID_PUBLIC": sheet_id}
    with open(SYNC_CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return {"status": "success", "sheet_id": sheet_id}

@app.post("/api/sheets/sync-now")
async def sync_sheets_now():
    if not os.path.exists(CREDS_PATH):
        raise HTTPException(status_code=400, detail="Chưa có file credentials.json!")
    if not os.path.exists(SYNC_CONFIG_PATH):
        raise HTTPException(status_code=400, detail="Chưa dán Link Google Sheet!")

    with open(SYNC_CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    sheet_id = cfg.get("SHEET_ID_PUBLIC")
    if not sheet_id:
        raise HTTPException(status_code=400, detail="Link Google Sheet không hợp lệ!")

    def _sync():
        scopes = ["https://www.googleapis.com/auth/spreadsheets", "https://www.googleapis.com/auth/drive"]
        creds = Credentials.from_service_account_file(CREDS_PATH, scopes=scopes)
        gc = gspread.authorize(creds)
        sh = gc.open_by_key(sheet_id)
        try:
            ws = sh.worksheet("DoanhThu")
        except Exception:
            ws = sh.add_worksheet(title="DoanhThu", rows=100, cols=10)
            ws.append_row(["Mã Vé", "Thời Gian", "Biển Số", "Kỹ Thuật", "Dịch Vụ", "Tổng Tiền", "Thanh Toán"])

        conn = get_db()
        cur = conn.cursor()
        cur.execute("""
            SELECT t.id, datetime(t.completed_at, '+7 hours') as completed_vn, 
                   t.plate_number, COALESCE(e.name, 'Chưa gán') as tech,
                   COALESCE(t.notes, '') as services, t.total_amount, t.payment_method
            FROM tickets t
            LEFT JOIN employees e ON t.technician_id = e.id
            WHERE t.status = 'HOAN_TAT' AND date(t.completed_at, '+7 hours') = date('now', '+7 hours')
        """)
        rows = cur.fetchall()
        conn.close()

        data_rows = []
        for r in rows:
            data_rows.append([
                r["id"], str(r["completed_vn"]), r["plate_number"], r["tech"],
                r["services"], r["total_amount"], r["payment_method"]
            ])

        if data_rows:
            ws.append_rows(data_rows)
        return len(data_rows)

    count = await run_in_threadpool(_sync)
    return {"status": "success", "synced_rows": count}

# Báo cáo theo khoảng thời gian
def build_date_filter_clause(filter_type: str, from_val: str, to_val: str):
    where_clauses = ["t.status = 'HOAN_TAT'"]
    params = []

    if filter_type == 'day' and from_val and to_val:
        where_clauses.append("date(t.completed_at, '+7 hours') BETWEEN ? AND ?")
        params.extend([from_val, to_val])
    elif filter_type == 'month' and from_val and to_val:
        where_clauses.append("strftime('%Y-%m', datetime(t.completed_at, '+7 hours')) BETWEEN ? AND ?")
        params.extend([from_val, to_val])
    elif filter_type == 'year' and from_val and to_val:
        where_clauses.append("strftime('%Y', datetime(t.completed_at, '+7 hours')) BETWEEN ? AND ?")
        params.extend([from_val, to_val])
    else:
        where_clauses.append("date(t.completed_at, '+7 hours') = date('now', '+7 hours')")

    return " AND ".join(where_clauses), params

@app.get("/api/reports/detailed")
def get_detailed_report(
    filter_type: str = Query("day"),
    from_val: str = Query(""),
    to_val: str = Query("")
):
    conn = get_db()
    cur = conn.cursor()
    where_sql, params = build_date_filter_clause(filter_type, from_val, to_val)

    cur.execute(f"""
        SELECT t.id, t.plate_number, t.plate_image_path, COALESCE(e.name, 'Chưa gán') as tech_name,
               COALESCE(t.notes, 'Chưa nhập') as service_names, t.total_amount,
               t.status, strftime('%H:%M - %d/%m/%Y', datetime(t.completed_at, '+7 hours')) as completed_time
        FROM tickets t
        LEFT JOIN employees e ON t.technician_id = e.id
        WHERE {where_sql}
        ORDER BY t.id DESC
    """, params)
    tickets = [dict(r) for r in cur.fetchall()]

    cur.execute(f"""
        SELECT e.name, COUNT(t.id) as car_count, COALESCE(SUM(t.total_amount), 0) as total_rev
        FROM employees e
        LEFT JOIN tickets t ON t.technician_id = e.id AND {where_sql}
        GROUP BY e.id
    """, params)
    emp_stats = [dict(r) for r in cur.fetchall()]
    conn.close()

    total_rev = sum(t["total_amount"] for t in tickets)
    return {
        "tickets": tickets,
        "employees": emp_stats,
        "total_revenue": total_rev,
        "total_cars": len(tickets)
    }

@app.get("/api/reports/export-excel")
def export_excel(
    filter_type: str = Query("day"),
    from_val: str = Query(""),
    to_val: str = Query("")
):
    conn = get_db()
    cur = conn.cursor()
    where_sql, params = build_date_filter_clause(filter_type, from_val, to_val)

    cur.execute(f"""
        SELECT t.id, datetime(t.completed_at, '+7 hours') as time_vn, t.plate_number, 
               COALESCE(e.name, '---') as tech, COALESCE(t.notes, '---') as srv, 
               t.total_amount, t.payment_method
        FROM tickets t
        LEFT JOIN employees e ON t.technician_id = e.id
        WHERE {where_sql}
        ORDER BY t.id DESC
    """, params)
    rows = cur.fetchall()
    conn.close()

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Báo Cáo Doanh Thu"
    headers = ["Mã Vé", "Thời Gian Hoàn Tất", "Biển Số", "Kỹ Thuật", "Dịch Vụ", "Tổng Tiền (VNĐ)", "Hình Thức"]
    ws.append(headers)

    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="1668E3", fill_type="solid")
        cell.alignment = Alignment(horizontal="center")

    for r in rows:
        ws.append([r[0], str(r[1]), r[2], r[3], r[4], r[5], r[6] or "Tiền mặt"])

    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = 22

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename=BaoCaoLopXe_{from_val}_den_{to_val}.xlsx"}
    )

@app.get("/api/reports/export-pdf")
def export_pdf(
    filter_type: str = Query("day"),
    from_val: str = Query(""),
    to_val: str = Query("")
):
    conn = get_db()
    cur = conn.cursor()
    where_sql, params = build_date_filter_clause(filter_type, from_val, to_val)

    cur.execute(f"""
        SELECT t.id, t.plate_number, COALESCE(e.name, '---') as tech,
               COALESCE(t.notes, '---') as srv, t.total_amount
        FROM tickets t
        LEFT JOIN employees e ON t.technician_id = e.id
        WHERE {where_sql}
        ORDER BY t.id DESC
    """, params)
    rows = cur.fetchall()
    conn.close()

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=25, leftMargin=25, topMargin=25, bottomMargin=25)
    elements = []
    styles = getSampleStyleSheet()

    elements.append(Paragraph("<b>HE THONG QUAN LY LOP XE PRO</b>", styles['Title']))
    elements.append(Paragraph(f"Bao cao ky: {from_val} den {to_val}", styles['Normal']))
    elements.append(Spacer(1, 15))

    table_data = [["Ma", "Bien So", "Tho", "Dich Vu", "Tong Tien"]]
    for r in rows:
        table_data.append([
            str(r[0]), str(r[1]), str(r[2]), str(r[3])[:25], f"{int(r[4]):,} d"
        ])

    table = Table(table_data, colWidths=[40, 95, 100, 200, 105])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1668E3')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
    ]))
    elements.append(table)
    doc.build(elements)
    buffer.seek(0)
    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=BaoCaoLopXe_{from_val}_den_{to_val}.pdf"}
    )

# Backup & Restore
@app.get("/api/backup/download")
def download_backup():
    if os.path.exists(DB_PATH):
        return FileResponse(DB_PATH, filename=f"lopxe_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db")
    raise HTTPException(status_code=404, detail="Không tìm thấy CSDL!")

@app.post("/api/backup/restore")
async def restore_backup(file: UploadFile = File(...)):
    contents = await file.read()
    with open(DB_PATH, "wb") as f:
        f.write(contents)
    return {"status": "success", "message": "Khôi phục CSDL thành công! Vui lòng tải lại trang."}

@app.get("/", response_class=HTMLResponse)
def index():
    with open(os.path.join(APP_DIR, "templates", "index.html"), "r", encoding="utf-8") as f:
        return f.read()

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$PackagingRoot = $PSScriptRoot
$ProjectRoot = Split-Path -Parent $PackagingRoot
$AgentRoot = Join-Path $ProjectRoot "local-ai-agent"
$OutputRoot = Join-Path $PackagingRoot "output"
$BuildRoot = Join-Path $PackagingRoot "pyinstaller-build"
$DistRoot = Join-Path $PackagingRoot "pyinstaller-dist"
$ModelRoot = Join-Path $PackagingRoot "server\models\easyocr"

Write-Host "[1/7] Preparing build directories"
foreach ($Path in @($OutputRoot, $BuildRoot, $DistRoot)) {
    if (Test-Path $Path) { Remove-Item -Recurse -Force $Path }
    New-Item -ItemType Directory -Force -Path $Path | Out-Null
}
New-Item -ItemType Directory -Force -Path (Join-Path $BuildRoot "spec") | Out-Null
New-Item -ItemType Directory -Force -Path $ModelRoot | Out-Null

Write-Host "[2/7] Installing CPU-only AI build dependencies"
python -m pip install --upgrade pip
python -m pip install torch==2.5.1 torchvision==0.20.1 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r (Join-Path $AgentRoot "requirements.txt") pyinstaller==6.16.0

Write-Host "[3/7] Downloading EasyOCR models for offline installation"
$env:LOPXE_EASYOCR_MODEL_DIR = $ModelRoot
$env:LOPXE_EASYOCR_ALLOW_DOWNLOAD = "1"
python -c "import easyocr, os; easyocr.Reader(['en'], gpu=False, verbose=False, model_storage_directory=os.environ['LOPXE_EASYOCR_MODEL_DIR'], download_enabled=True); print('EasyOCR models ready')"

Write-Host "[4/7] Building Windows AI and Server executables"
python -m PyInstaller --noconfirm --clean --onedir --windowed `
    --name LopXeAI `
    --distpath $DistRoot `
    --workpath (Join-Path $BuildRoot "ai") `
    --specpath (Join-Path $BuildRoot "spec") `
    --paths $AgentRoot `
    --collect-all easyocr `
    --collect-all torchvision `
    --exclude-module matplotlib `
    --exclude-module pandas `
    --exclude-module IPython `
    (Join-Path $AgentRoot "agent.py")

python -m PyInstaller --noconfirm --clean --onefile --windowed `
    --name LopXeServerManager `
    --distpath $DistRoot `
    --workpath (Join-Path $BuildRoot "manager") `
    --specpath (Join-Path $BuildRoot "spec") `
    --paths (Join-Path $PackagingRoot "server") `
    (Join-Path $PackagingRoot "server\server_manager.py")

python -m PyInstaller --noconfirm --clean --onefile --windowed `
    --name LopXeServiceHost `
    --distpath $DistRoot `
    --workpath (Join-Path $BuildRoot "host") `
    --specpath (Join-Path $BuildRoot "spec") `
    --paths (Join-Path $PackagingRoot "server") `
    (Join-Path $PackagingRoot "server\service_host.py")

$ServerOutput = Join-Path $OutputRoot "server"
New-Item -ItemType Directory -Force -Path $ServerOutput | Out-Null
Copy-Item (Join-Path $DistRoot "LopXeAI") (Join-Path $ServerOutput "LopXeAI") -Recurse -Force
Copy-Item (Join-Path $DistRoot "LopXeServerManager.exe") $ServerOutput -Force
Copy-Item (Join-Path $DistRoot "LopXeServiceHost.exe") $ServerOutput -Force
Copy-Item (Join-Path $PackagingRoot "server\server_config.example.json") $ServerOutput -Force
Copy-Item (Join-Path $PackagingRoot "server\models") (Join-Path $ServerOutput "models") -Recurse -Force

Write-Host "[5/7] Building self-contained Windows Client"
$ClientOutput = Join-Path $OutputRoot "client"
dotnet publish (Join-Path $PackagingRoot "client\LopXeClient.csproj") `
    --configuration Release `
    --runtime win-x64 `
    --self-contained true `
    -p:PublishSingleFile=false `
    --output $ClientOutput

Write-Host "[6/7] Downloading the official WebView2 bootstrapper"
Invoke-WebRequest -UseBasicParsing `
    -Uri "https://go.microsoft.com/fwlink/p/?LinkId=2124703" `
    -OutFile (Join-Path $OutputRoot "MicrosoftEdgeWebview2Setup.exe")

Write-Host "[7/7] Compiling the two Windows installers"
$IsccCandidates = @(
    (Join-Path ${env:ProgramFiles(x86)} "Inno Setup 6\ISCC.exe"),
    (Join-Path $env:ProgramFiles "Inno Setup 6\ISCC.exe")
)
$Iscc = $IsccCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $Iscc) { throw "Inno Setup 6 was not found." }

& $Iscc (Join-Path $PackagingRoot "installer\LopXeServer.iss")
& $Iscc (Join-Path $PackagingRoot "installer\LopXeClient.iss")

$ServerSetup = Join-Path $OutputRoot "LopXe_Server_Setup_1.4.1.exe"
$ClientSetup = Join-Path $OutputRoot "LopXe_Client_Setup_1.4.1.exe"
if (-not (Test-Path $ServerSetup)) { throw "Server installer was not created." }
if (-not (Test-Path $ClientSetup)) { throw "Client installer was not created." }

$Checksums = @(
    "$(Get-FileHash $ServerSetup -Algorithm SHA256 | Select-Object -ExpandProperty Hash)  $(Split-Path $ServerSetup -Leaf)",
    "$(Get-FileHash $ClientSetup -Algorithm SHA256 | Select-Object -ExpandProperty Hash)  $(Split-Path $ClientSetup -Leaf)"
)
$Checksums | Set-Content -Encoding ASCII (Join-Path $OutputRoot "SHA256SUMS.txt")
Write-Host "Build completed successfully."

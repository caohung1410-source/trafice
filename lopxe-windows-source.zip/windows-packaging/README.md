# Bộ cài Windows Lốp Xe Pro 1.4.1

## Lốp Xe Server Setup.exe

- Cài AI ANPR Việt Nam chạy local trên Windows 10/11 x64.
- Cấu hình Google Apps Script Web App URL và AI API key.
- Thêm/sửa/xóa nhiều camera RTSP và gán từng làn dịch vụ.
- Tự dò thiết bị mở cổng RTSP 554 trong lớp mạng LAN.
- Kiểm tra từng cấu hình RTSP bằng ô chụp hình nhỏ trước khi lưu.
- Chạy một tiến trình AI riêng cho mỗi camera, tự khởi động lại khi mất luồng.
- Chặn chạy trùng Server/AI khi người dùng bấm lưu nhiều lần.
- Phát hiện Server trong LAN bằng UDP 43991 cho các máy Client.
- OCR EasyOCR được đóng gói. Nếu chưa có model ONNX biển số chuyên dụng, hệ thống dùng detector hình học dự phòng.

## Lốp Xe Client Setup.exe

- Một bộ cài dùng cho máy Quản lý, Kế toán và Kỹ thuật.
- Tự tìm Server trong LAN hoặc nhập URL thủ công.
- Chỉ chấp nhận HTTPS; HTTP chỉ cho phép địa chỉ mạng nội bộ.
- Mở giao diện bằng Microsoft Edge WebView2.

## Lưu ý triển khai

- Không đưa RTSP, mật khẩu camera hoặc API key thật lên GitHub.
- Dữ liệu nghiệp vụ vẫn lưu qua Google Apps Script + Google Sheet hiện hữu.
- Cần đo thực tế bằng camera tại cửa hàng trước khi chốt ngưỡng nhận diện.

## Tự động build trên GitHub

- Workflow dùng Windows runner, Python 3.11, .NET 8 và Inno Setup 6.
- Chạy `windows-packaging/build-windows.ps1` để tạo đúng hai bộ cài x64.
- Kết quả gồm hai file EXE và `SHA256SUMS.txt` trong GitHub Actions Artifact.
- Bộ cài chưa ký số; Windows SmartScreen có thể hiện cảnh báo ở lần cài đầu.

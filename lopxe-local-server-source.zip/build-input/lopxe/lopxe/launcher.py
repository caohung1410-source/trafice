"""Windows entry point for the Lốp Xe Pro local server."""
from __future__ import annotations

import os
import socket
import threading
import webbrowser
from pathlib import Path


PORT = 8000


def server_is_running() -> bool:
    try:
        with socket.create_connection(("127.0.0.1", PORT), timeout=0.4):
            return True
    except OSError:
        return False


def main() -> None:
    data_dir = Path(os.environ.get("PROGRAMDATA", str(Path.home()))) / "LopXePro"
    data_dir.mkdir(parents=True, exist_ok=True)
    models_dir = data_dir / "easyocr-models"
    models_dir.mkdir(parents=True, exist_ok=True)
    os.environ["LOPXE_DATA_DIR"] = str(data_dir)
    os.environ["LOPXE_EASYOCR_MODEL_DIR"] = str(models_dir)
    os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "rtsp_transport;tcp")

    url = f"http://127.0.0.1:{PORT}"
    if server_is_running():
        webbrowser.open(url)
        return

    threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    import uvicorn
    import server
    uvicorn.run(server.app, host="0.0.0.0", port=PORT, log_level="warning")


if __name__ == "__main__":
    main()

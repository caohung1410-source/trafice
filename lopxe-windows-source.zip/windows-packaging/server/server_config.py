from __future__ import annotations

import copy
import json
import os
from pathlib import Path
from typing import Any

import yaml


APP_VERSION = "1.4.1"
DATA_DIR = Path(os.environ.get("PROGRAMDATA", str(Path.home()))) / "LopXePro"
CONFIG_FILE = DATA_DIR / "server_config.json"

DEFAULT_CONFIG: dict[str, Any] = {
    "server_name": "LOPXE-SERVER",
    "web_app_url": "",
    "api_key": "",
    "udp_discovery_port": 43991,
    "cameras": [],
    "ai": {
        "detector_input_size": 640,
        "detector_confidence": 0.32,
        "nms_threshold": 0.45,
        "fallback_geometric_detector": True,
        "gpu": False,
        "process_fps": 8,
        "max_candidates_per_frame": 6,
        "min_ocr_confidence": 0.42,
        "min_plate_confidence": 0.68,
        "vote_window_seconds": 2.5,
        "vote_min_hits": 3,
        "vote_min_ratio": 0.55,
        "vote_max_edit_distance": 1,
        "duplicate_cooldown_seconds": 15,
    },
}


def load_server_config() -> dict[str, Any]:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        return copy.deepcopy(DEFAULT_CONFIG)
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return copy.deepcopy(DEFAULT_CONFIG)
    merged = copy.deepcopy(DEFAULT_CONFIG)
    merged.update(data if isinstance(data, dict) else {})
    merged["ai"].update(data.get("ai", {}) if isinstance(data, dict) else {})
    if not isinstance(merged.get("cameras"), list):
        merged["cameras"] = []
    return merged


def save_server_config(config: dict[str, Any]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = CONFIG_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(CONFIG_FILE)


def generate_camera_configs(config: dict[str, Any], app_dir: Path) -> list[tuple[dict[str, Any], Path]]:
    camera_dir = DATA_DIR / "cameras"
    log_dir = DATA_DIR / "logs"
    model_dir = DATA_DIR / "models"
    camera_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    model_dir.mkdir(parents=True, exist_ok=True)
    generated: list[tuple[dict[str, Any], Path]] = []

    for index, camera in enumerate(config.get("cameras", []), 1):
        if not camera.get("enabled", True) or not str(camera.get("rtsp_url", "")).strip():
            continue
        camera_id = str(camera.get("id") or f"CAM-{index:02d}")
        safe_id = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in camera_id)
        ai_cfg = copy.deepcopy(config.get("ai", {}))
        ai_cfg["detector_onnx"] = str(model_dir / "license_plate_detector.onnx")
        payload = {
            "agent": {
                "id": f"LX-AGENT-{safe_id}",
                "name": f"Lop Xe Pro AI - {camera.get('name', camera_id)}",
                "version": APP_VERSION,
            },
            "google_apps_script": {
                "web_app_url": str(config.get("web_app_url", "")).strip(),
                "api_key": str(config.get("api_key", "")).strip(),
            },
            "camera": {
                "remote_config": False,
                "camera_id": camera_id,
                "name": str(camera.get("name") or camera_id),
                "lane": str(camera.get("lane") or "Làn 1"),
                "rtsp_url": str(camera.get("rtsp_url", "")).strip(),
                "reconnect_seconds": int(camera.get("reconnect_seconds", 3)),
            },
            "ai": ai_cfg,
            "preview": {
                "enabled": bool(camera.get("preview", True)),
                "width": int(camera.get("preview_width", 960)),
            },
            "logging": {
                "level": "INFO",
                "file": str(log_dir / f"{safe_id}.log"),
            },
        }
        path = camera_dir / f"{safe_id}.yaml"
        path.write_text(yaml.safe_dump(payload, allow_unicode=True, sort_keys=False), encoding="utf-8")
        generated.append((camera, path))
    return generated

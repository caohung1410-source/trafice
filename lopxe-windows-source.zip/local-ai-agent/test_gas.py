import yaml
from gas_client import GASClient
with open('config.yaml','r',encoding='utf-8') as f: cfg=yaml.safe_load(f)
g=cfg['google_apps_script']; c=cfg['camera']; a=cfg['agent']
cli=GASClient(g['web_app_url'],g['api_key'])
print('REMOTE CONFIG:', cli.get_agent_config(c.get('camera_id','')))
print('HEARTBEAT:', cli.heartbeat(agent_id=a['id'],agent_name=a['name'],camera_id=c.get('camera_id',''),version=a.get('version','1.1.0'),fps=0,status='TEST',message='Ket noi OK'))

from __future__ import annotations
import base64
import socket
from dataclasses import dataclass
from typing import Any, Dict, Optional
import cv2
import requests


@dataclass
class GASClient:
    web_app_url: str
    api_key: str
    timeout: int = 12

    def _post(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        body = dict(payload)
        body["apiKey"] = self.api_key
        r = requests.post(self.web_app_url, json=body, timeout=self.timeout)
        r.raise_for_status()
        data = r.json()
        if not data.get("ok"):
            raise RuntimeError(data.get("error") or "GAS returned error")
        return data

    def get_agent_config(self, camera_id: str = "") -> Dict[str, Any]:
        params = {"api": "agent_config", "apiKey": self.api_key}
        if camera_id:
            params["cameraId"] = camera_id
        r = requests.get(self.web_app_url, params=params, timeout=self.timeout)
        r.raise_for_status()
        data = r.json()
        if not data.get("ok"):
            raise RuntimeError(data.get("error") or "Cannot load remote config")
        return data

    def send_plate(self, *, camera_id: str, camera_name: str, plate: str,
                   confidence: float, image_bgr=None, duplicate_window_sec: int = 12,
                   timestamp: str = "", metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "action": "plate_event",
            "cameraId": camera_id,
            "cameraName": camera_name,
            "plate": plate,
            "confidence": round(float(confidence), 4),
            "duplicateWindowSec": int(duplicate_window_sec),
        }
        if timestamp:
            payload["timestamp"] = timestamp
        if metadata:
            payload["anprMeta"] = metadata
        if image_bgr is not None:
            ok, buf = cv2.imencode(".jpg", image_bgr, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
            if ok:
                payload["imageBase64"] = base64.b64encode(buf.tobytes()).decode("ascii")
        return self._post(payload)

    def heartbeat(self, *, agent_id: str, agent_name: str, camera_id: str,
                  version: str, fps: float, last_plate: str = "", status: str = "ONLINE",
                  message: str = "") -> Dict[str, Any]:
        try:
            ip = socket.gethostbyname(socket.gethostname())
        except Exception:
            ip = ""
        return self._post({
            "action": "heartbeat",
            "agentId": agent_id,
            "agentName": agent_name,
            "cameraId": camera_id,
            "version": version,
            "fps": round(float(fps), 2),
            "lastPlate": last_plate,
            "status": status,
            "message": message,
            "ip": ip,
        })

function parseIsoMs_(s) {
  const t = new Date(String(s || '').replace(' ', 'T')).getTime();
  return Number.isFinite(t) ? t : 0;
}

function agentOfflineSeconds_() {
  const settings = settingsMap_();
  return Math.max(30, Number(settings.AGENT_OFFLINE_SECONDS || APP.AGENT_OFFLINE_SECONDS));
}

function normalizeAgentForClient_(x) {
  const now = Date.now();
  const seen = parseIsoMs_(x.lastSeen);
  const ageSec = seen ? Math.max(0, Math.floor((now - seen) / 1000)) : 999999;
  return Object.assign({}, x, { version:String(x.version || ''), fps:safeNumber_(x.fps), ageSeconds:ageSec, status: ageSec > agentOfflineSeconds_() ? 'OFFLINE' : 'ONLINE' });
}

function apiListAgents(token) {
  requireSession_(token);
  return listObjects_(APP.SHEETS.AGENTS).map(normalizeAgentForClient_).sort((a,b)=>String(b.lastSeen).localeCompare(String(a.lastSeen)));
}

function apiListPlateEvents(token, limit) {
  requireSession_(token);
  return listObjects_(APP.SHEETS.PLATE_EVENTS).sort((a,b)=>String(b.timestamp).localeCompare(String(a.timestamp))).slice(0, Math.min(100, Math.max(1, Number(limit || 20))));
}

function apiGetLatestPlateEvent(token, afterTimestamp) {
  requireSession_(token);
  let rows = listObjects_(APP.SHEETS.PLATE_EVENTS);
  if (afterTimestamp) rows = rows.filter(x => String(x.timestamp) > String(afterTimestamp));
  rows.sort((a,b)=>String(b.timestamp).localeCompare(String(a.timestamp)));
  return rows[0] || null;
}

function savePlateImage_(payload, plate) {
  if (!payload || !payload.imageBase64) return String(payload && payload.imageUrl || '');
  try {
    const props = PropertiesService.getScriptProperties();
    let folderId = props.getProperty('AI_SNAPSHOT_FOLDER_ID');
    let folder = folderId ? DriveApp.getFolderById(folderId) : null;
    if (!folder) { folder = DriveApp.createFolder('LopXePro_AI_Snapshots'); props.setProperty('AI_SNAPSHOT_FOLDER_ID', folder.getId()); }
    const raw = String(payload.imageBase64).replace(/^data:image\/\w+;base64,/, '');
    const file = folder.createFile(Utilities.newBlob(Utilities.base64Decode(raw), 'image/jpeg', 'PLATE_' + normalizePlate_(plate) + '_' + Utilities.formatDate(new Date(), APP.TZ, 'yyyyMMdd_HHmmss') + '.jpg'));
    return file.getUrl();
  } catch (e) {
    return String(payload.imageUrl || '');
  }
}

function savePlateEvent_(payload) {
  payload = payload || {};
  const plate = normalizePlate_(payload.plate);
  if (!plate) throw new Error('Thiếu biển số.');
  const camera = payload.cameraId ? getByField_(APP.SHEETS.CAMERAS, 'id', payload.cameraId) : null;
  return appendObject_(APP.SHEETS.PLATE_EVENTS, {
    id:newId_('PLATE'), timestamp:String(payload.timestamp || nowIso_()),
    cameraId: camera ? camera.id : String(payload.cameraId || ''),
    cameraName: camera ? camera.name : String(payload.cameraName || ''),
    plate:plate, confidence:safeNumber_(payload.confidence), imageUrl:savePlateImage_(payload, plate), rawJson:JSON.stringify(payload), used:false
  });
}

function saveAgentHeartbeat_(payload) {
  payload = payload || {};
  const agentId = String(payload.agentId || 'LOCAL_AI_AGENT');
  const ex = getByField_(APP.SHEETS.AGENTS, 'id', agentId);
  const data = {
    id:agentId, name:String(payload.agentName || agentId), cameraId:String(payload.cameraId || ''), lastSeen:String(payload.timestamp || nowIso_()), status:String(payload.status || 'ONLINE'), version:String(payload.version || ''), ip:String(payload.ip || ''), fps:safeNumber_(payload.fps), lastPlate:normalizePlate_(payload.lastPlate || ''), message:String(payload.message || ''), updatedAt:nowIso_()
  };
  return ex ? updateById_(APP.SHEETS.AGENTS, agentId, data) : appendObject_(APP.SHEETS.AGENTS, data);
}

function getAgentConfig_(apiKey, cameraId) {
  const expected = PropertiesService.getScriptProperties().getProperty('AI_API_KEY');
  if (!expected || String(apiKey || '') !== expected) throw new Error('UNAUTHORIZED');
  const cameras = listObjects_(APP.SHEETS.CAMERAS).filter(x => asBool_(x.enabled));
  let camera = null;
  if (cameraId) camera = cameras.find(x => String(x.id) === String(cameraId)) || null;
  if (!camera && cameras.length === 1) camera = cameras[0];
  return { ok:true, app:APP.NAME, version:APP.VERSION, settings:settingsMap_(), camera, cameras:cameras };
}

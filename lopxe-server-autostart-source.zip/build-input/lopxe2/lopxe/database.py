import os
import sqlite3
from pathlib import Path

BUNDLE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("LOPXE_DATA_DIR", str(BUNDLE_DIR)))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = str(DATA_DIR / "lopxe.db")


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, fullname TEXT, role TEXT);
        CREATE TABLE IF NOT EXISTS lanes (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT);
        CREATE TABLE IF NOT EXISTS cameras (id INTEGER PRIMARY KEY AUTOINCREMENT, lane_id INTEGER, name TEXT, model TEXT, rtsp_url TEXT);
        CREATE TABLE IF NOT EXISTS employees (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS services (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, price REAL, unit TEXT DEFAULT 'Lần', active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, sku TEXT, unit TEXT, quantity REAL DEFAULT 0, cost_price REAL DEFAULT 0, sell_price REAL DEFAULT 0, active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS tickets (id INTEGER PRIMARY KEY AUTOINCREMENT, lane_id INTEGER, plate_number TEXT, plate_image_path TEXT, technician_id INTEGER, status TEXT DEFAULT 'CHO_TIEP_NHAN', total_amount REAL DEFAULT 0, is_stock_exported INTEGER DEFAULT 0, is_paid INTEGER DEFAULT 0, payment_method TEXT DEFAULT 'TIEN_MAT', notes TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, completed_at TIMESTAMP);
        CREATE TABLE IF NOT EXISTS ticket_items (id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER, item_type TEXT, item_id INTEGER, item_name TEXT, quantity REAL, unit_price REAL, total_price REAL, employee_id INTEGER, notes TEXT);
        CREATE TABLE IF NOT EXISTS inventory_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, ticket_id INTEGER, quantity_change REAL, reason TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS sync_queue (id INTEGER PRIMARY KEY AUTOINCREMENT, entity TEXT, entity_id INTEGER, payload TEXT, status TEXT DEFAULT 'PENDING', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS bill_templates (id INTEGER PRIMARY KEY AUTOINCREMENT, shop_name TEXT DEFAULT 'TRUNG TÂM DỊCH VỤ LỐP XE PRO', address TEXT DEFAULT '', phone TEXT DEFAULT '', footer_note TEXT DEFAULT 'Cảm ơn Quý khách & Hẹn gặp lại!', paper_size TEXT DEFAULT 'K80', show_plate_img INTEGER DEFAULT 1, show_bank_qr INTEGER DEFAULT 0, bank_account TEXT DEFAULT '', bank_name TEXT DEFAULT '');
    """)
    if cur.execute("SELECT COUNT(*) FROM bill_templates").fetchone()[0] == 0:
        cur.execute("INSERT INTO bill_templates (id) VALUES (1)")
    if cur.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        cur.executemany("INSERT INTO users (username, password, fullname, role) VALUES (?, ?, ?, ?)", [
            ("quanly", "123456", "Quản Lý Hệ Thống", "QUAN_LY"),
            ("ketoan", "123456", "Thu Ngân Kế Toán", "KE_TOAN"),
            ("kythuat", "123456", "Kỹ Thuật Viên Xưởng", "KY_THUAT"),
        ])
    if cur.execute("SELECT COUNT(*) FROM lanes").fetchone()[0] == 0:
        cur.execute("INSERT INTO lanes (name) VALUES ('Làn 1')")
    conn.commit()
    conn.close()


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

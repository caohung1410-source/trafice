function doGet(e) {
  try {
    const p = (e && e.parameter) || {};
    if (String(p.api || '') === 'agent_config') return json_(getAgentConfig_(p.apiKey, p.cameraId));
  } catch (err) {
    return json_({ ok:false, error:String(err && err.message ? err.message : err) });
  }
  const t = HtmlService.createTemplateFromFile('Index');
  t.appName = APP.NAME;
  t.version = APP.VERSION;
  return t.evaluate().setTitle(APP.NAME).setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL).addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function include(filename) { return HtmlService.createHtmlOutputFromFile(filename).getContent(); }

function doPost(e) {
  try {
    const expected = PropertiesService.getScriptProperties().getProperty('AI_API_KEY');
    if (!expected) throw new Error('AI API Key chưa được khởi tạo.');
    let payload = {};
    const type = String((e && e.postData && e.postData.type) || '').toLowerCase();
    if (type.includes('application/json')) payload = JSON.parse(e.postData.contents || '{}');
    else {
      payload = Object.assign({}, e ? e.parameter : {});
      if (payload.payload) { try { payload = JSON.parse(payload.payload); } catch (err) {} }
    }
    const provided = String(payload.apiKey || (e && e.parameter && e.parameter.apiKey) || '');
    if (provided !== expected) return json_({ ok:false, error:'UNAUTHORIZED' });
    const action = String(payload.action || 'plate_event');
    if (action === 'plate_event') {
      const event = savePlateEvent_(payload);
      return json_({ ok:true, eventId:event.id, plate:event.plate });
    }
    if (action === 'heartbeat') {
      const agent = saveAgentHeartbeat_(payload);
      return json_({ ok:true, agentId:agent.id, lastSeen:agent.lastSeen });
    }
    return json_({ ok:false, error:'UNKNOWN_ACTION' });
  } catch (err) {
    return json_({ ok:false, error:String(err && err.message ? err.message : err) });
  }
}

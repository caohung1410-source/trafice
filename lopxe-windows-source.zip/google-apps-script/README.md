# Lốp Xe Pro Hybrid v1.2.3 – 3 giao diện

Nâng trực tiếp từ v1.2.x, giữ nguyên Google Sheet/database đang dùng.

## Giao diện
- Quản lý: toàn quyền, tiếp nhận xe, phiếu, kế toán, báo cáo, camera AI, nhân viên, dịch vụ/đơn giá, cài đặt.
- Kế toán: thu tiền, sổ thu, báo cáo. Không được sửa nhân viên/camera/đơn giá.
- Kỹ thuật: hàng đợi công việc, bắt đầu/hoàn thành, ghi chú kỹ thuật; không trả dữ liệu doanh thu/đơn giá.

## PIN mặc định khi migrate nếu chưa có
- Quản lý: giữ PIN hiện tại (nếu cài mới: 123456)
- Kế toán: 234567
- Kỹ thuật: 345678

Đổi PIN trong giao diện Quản lý > Cài đặt sau khi chạy ổn.

## Fix v1.2.3
- Agent version không còn bị Google Sheets đổi `1.2.0` thành ngày.
- Agent ONLINE/OFFLINE tính theo `lastSeen`, mặc định 90 giây.
- Dashboard AI tự refresh 10 giây.
- Local Agent không gửi heartbeat ngay khi FPS chưa đo xong.
- Schema migration an toàn: chỉ thêm cột thiếu, KHÔNG `clear()` sheet hiện hữu.
- Thêm trường kế toán: paymentStatus/paymentMethod/paidAt/accountingNote.
- Thêm trường kỹ thuật: startedAt/techNote.

## Nâng cấp từ bản đang chạy
1. Copy/replace toàn bộ file trong `google-apps-script/`.
2. Tạo tạm `AdminRun_v123.gs` bằng file trong thư mục `tools/`.
3. Save và chạy `UPGRADE_V123`.
4. Xóa file tạm `AdminRun_v123.gs`.
5. Deploy > Manage deployments > Edit > New version > Deploy.
6. Local AI Agent: copy đè `agent.py` và đổi version config thành 1.2.3, giữ nguyên `config.yaml` chứa RTSP/API key của máy bạn.
7. Giữ nguyên `models/license_plate_detector.onnx` đang hoạt động trên máy; gói này không nhúng lại trọng số model.

## Database
Không tạo Google Sheet mới nếu Script Properties đã có DATABASE_ID.

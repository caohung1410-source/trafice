import os

# Tạo cấu trúc thư mục
base_dir = os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(base_dir, "templates"), exist_ok=True)
os.makedirs(os.path.join(base_dir, "scripts"), exist_ok=True)

# 1. requirements.txt
requirements = """fastapi==0.110.0
uvicorn[standard]==0.28.0
pydantic==2.6.4
python-multipart==0.0.9
gspread==6.0.2
oauth2client==4.1.3
openpyxl==3.1.2
jinja2==3.1.3
websockets==12.0
"""
with open(os.path.join(base_dir, "requirements.txt"), "w", encoding="utf-8") as f:
    f.write(requirements)

# 2. database.py
database_code = '''import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "lopxe.db")

def get_db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()
    
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        fullname TEXT NOT NULL,
        role TEXT NOT NULL
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS employees (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        active INTEGER DEFAULT 1
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        unit TEXT DEFAULT 'Lần',
        active INTEGER DEFAULT 1
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sku TEXT UNIQUE,
        name TEXT NOT NULL,
        category TEXT,
        cost_price REAL DEFAULT 0,
        sell_price REAL NOT NULL,
        stock_quantity INTEGER DEFAULT 0,
        min_stock_level INTEGER DEFAULT 4,
        active INTEGER DEFAULT 1
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS lanes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        lane_id INTEGER,
        plate_number TEXT NOT NULL,
        technician_id INTEGER,
        status TEXT DEFAULT 'CHO_TIEP_NHAN',
        total_amount REAL DEFAULT 0,
        is_stock_exported INTEGER DEFAULT 0,
        is_paid INTEGER DEFAULT 0,
        payment_method TEXT,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        completed_at DATETIME
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS ticket_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id INTEGER,
        item_type TEXT,
        item_id INTEGER,
        item_name TEXT,
        quantity REAL DEFAULT 1,
        cost_price REAL DEFAULT 0,
        unit_price REAL,
        total_price REAL
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS inventory_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        transaction_type TEXT,
        quantity INTEGER,
        cost_price REAL DEFAULT 0,
        reference_id INTEGER,
        note TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS sync_queue (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id INTEGER,
        action TEXT,
        status TEXT DEFAULT 'PENDING',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    """)

    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        cur.executemany("INSERT INTO users (username, password, fullname, role) VALUES (?, ?, ?, ?)", [
            ('quanly', '123456', 'Quản Lý Cửa Hàng', 'QUAN_LY'),
            ('ketoan', '123456', 'Kế Toán Thu Ngân', 'KE_TOAN'),
            ('kythuat', '123456', 'Kỹ Thuật Viên Xưởng', 'KY_THUAT'),
        ])
        cur.executemany("INSERT INTO employees (name, phone) VALUES (?, ?)", [
            ('Nguyễn Văn Tuấn', '0905111222'),
            ('Trần Văn Hùng', '0905333444'),
            ('Lê Văn Bình', '0905555666'),
        ])
        cur.executemany("INSERT INTO services (name, price, unit) VALUES (?, ?, ?)", [
            ('Công thay vỏ lốp (1 bánh)', 50000, 'Bánh'),
            ('Cân mâm bấm chì vi tính', 80000, 'Bánh'),
            ('Cân chỉnh thước lái góc đặt bánh xe', 350000, 'Xe'),
            ('Vá lốp nấm công nghệ cao', 90000, 'Lỗ'),
            ('Bơm khí Nitơ toàn bộ 4 bánh', 100000, 'Xe'),
        ])
        cur.executemany("INSERT INTO products (sku, name, category, cost_price, sell_price, stock_quantity, min_stock_level) VALUES (?, ?, ?, ?, ?, ?, ?)", [
            ('LOP-MI-185-60R15', 'Lốp Michelin 185/60R15 Energy XM2+', 'Lốp xe', 1350000, 1750000, 16, 4),
            ('LOP-BS-205-55R16', 'Lốp Bridgestone 205/55R16 Turanza', 'Lốp xe', 1450000, 1900000, 12, 4),
            ('LOP-GY-215-60R17', 'Lốp Goodyear 215/60R17 Assurance', 'Lốp xe', 1600000, 2100000, 8, 4),
            ('VAN-CAO-SU', 'Van cao su không ruột TR414', 'Phụ tùng', 10000, 30000, 50, 10),
            ('NHOT-CASTROL-5W30', 'Nhớt Castrol Magnatec 5W-30 (4L)', 'Dầu nhớt', 450000, 680000, 15, 5),
        ])
        cur.executemany("INSERT INTO lanes (name) VALUES (?)", [('Làn 1 - Cầu Nâng 1',), ('Làn 2 - Cầu Nâng 2',)])

    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
    print("Khởi tạo database thành công!")
'''
with open(os.path.join(base_dir, "database.py"), "w", encoding="utf-8") as f:
    f.write(database_code)

# 3. server.py
server_code = '''import asyncio
import json
import sqlite3
import os
from datetime import datetime
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from typing import List, Optional
import openpyxl

from database import get_db, init_db, DB_PATH

init_db()
app = FastAPI(title="Hệ Thống Quản Lý Lốp Xe & Dịch Vụ Ô Tô")

class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_text(json.dumps(message))
            except Exception:
                pass

ws_manager = ConnectionManager()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)

class LoginReq(BaseModel):
    username: str
    password: str

class TicketCreateReq(BaseModel):
    lane_id: int
    plate_number: str

class TicketItemReq(BaseModel):
    item_type: str
    item_id: int
    quantity: float
    unit_price: float

class TechUpdateReq(BaseModel):
    technician_id: int
    plate_number: str
    items: List[TicketItemReq]
    notes: Optional[str] = ""

class CashierCompleteReq(BaseModel):
    payment_method: str

@app.post("/api/login")
def login(req: LoginReq):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, username, fullname, role FROM users WHERE username = ? AND password = ?", (req.username, req.password))
    u = cur.fetchone()
    conn.close()
    if not u:
        raise HTTPException(status_code=401, detail="Sai tên đăng nhập hoặc mật khẩu!")
    return {"id": u["id"], "username": u["username"], "fullname": u["fullname"], "role": u["role"]}

@app.get("/api/catalog")
def get_catalog(role: str = "KY_THUAT"):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, name, phone FROM employees WHERE active = 1")
    employees = [dict(r) for r in cur.fetchall()]
    cur.execute("SELECT id, name, price, unit FROM services WHERE active = 1")
    services = [dict(r) for r in cur.fetchall()]
    cur.execute("SELECT id, name FROM lanes")
    lanes = [dict(r) for r in cur.fetchall()]

    if role == "QUAN_LY":
        cur.execute("SELECT id, sku, name, category, cost_price, sell_price, stock_quantity, min_stock_level FROM products WHERE active = 1")
    else:
        cur.execute("SELECT id, sku, name, category, sell_price, stock_quantity, min_stock_level FROM products WHERE active = 1")
    products = [dict(r) for r in cur.fetchall()]

    conn.close()
    return {"employees": employees, "services": services, "products": products, "lanes": lanes}

@app.get("/api/tickets")
def get_tickets():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT t.id, t.lane_id, l.name as lane_name, t.plate_number, t.technician_id, e.name as tech_name,
               t.status, t.total_amount, t.is_stock_exported, t.is_paid, t.payment_method, t.notes, t.created_at, t.completed_at
        FROM tickets t
        LEFT JOIN lanes l ON t.lane_id = l.id
        LEFT JOIN employees e ON t.technician_id = e.id
        WHERE t.status != 'HOAN_TAT' ORDER BY t.id DESC
    """)
    rows = cur.fetchall()
    tickets = []
    for r in rows:
        d = dict(r)
        cur.execute("SELECT id, item_type, item_id, item_name, quantity, unit_price, total_price FROM ticket_items WHERE ticket_id = ?", (d["id"],))
        d["items"] = [dict(it) for it in cur.fetchall()]
        tickets.append(d)
    conn.close()
    return tickets

@app.post("/api/tickets")
async def create_ticket(req: TicketCreateReq):
    plate = req.plate_number.strip().upper()
    if not plate:
        raise HTTPException(status_code=400, detail="Biển số không được trống!")
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id FROM tickets WHERE plate_number = ? AND status != 'HOAN_TAT'", (plate,))
    if cur.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail=f"Xe {plate} đang trong xưởng!")
    cur.execute("INSERT INTO tickets (lane_id, plate_number, status) VALUES (?, ?, 'CHO_TIEP_NHAN')", (req.lane_id, plate))
    tid = cur.lastrowid
    conn.commit()
    conn.close()
    await ws_manager.broadcast({"event": "NEW_TICKET", "ticket_id": tid})
    return {"id": tid}

@app.put("/api/tickets/{ticket_id}/tech-update")
async def tech_update(ticket_id: int, req: TechUpdateReq):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM ticket_items WHERE ticket_id = ?", (ticket_id,))
    total_amount = 0.0
    for it in req.items:
        cost = 0.0
        item_name = ""
        if it.item_type == "PRODUCT":
            cur.execute("SELECT name, cost_price FROM products WHERE id = ?", (it.item_id,))
            p = cur.fetchone()
            if p: item_name, cost = p["name"], p["cost_price"]
        else:
            cur.execute("SELECT name FROM services WHERE id = ?", (it.item_id,))
            s = cur.fetchone()
            if s: item_name = s["name"]
        tot = it.quantity * it.unit_price
        total_amount += tot
        cur.execute("INSERT INTO ticket_items (ticket_id, item_type, item_id, item_name, quantity, cost_price, unit_price, total_price) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (ticket_id, it.item_type, it.item_id, item_name, it.quantity, cost, it.unit_price, tot))

    cur.execute("UPDATE tickets SET technician_id = ?, plate_number = ?, total_amount = ?, notes = ? WHERE id = ?",
                (req.technician_id, req.plate_number.strip().upper(), total_amount, req.notes, ticket_id))
    conn.commit()
    conn.close()
    await ws_manager.broadcast({"event": "TICKET_UPDATED", "ticket_id": ticket_id})
    return {"status": "success"}

@app.post("/api/tickets/{ticket_id}/tech-complete")
async def tech_complete(ticket_id: int):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT technician_id, total_amount, plate_number FROM tickets WHERE id = ?", (ticket_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Không tìm thấy lượt xe")

    cur.execute("SELECT COUNT(*) FROM ticket_items WHERE ticket_id = ?", (ticket_id,))
    if not row["technician_id"]:
        conn.close()
        raise HTTPException(status_code=400, detail="Chưa gán thợ kỹ thuật!")
    if cur.fetchone()[0] == 0:
        conn.close()
        raise HTTPException(status_code=400, detail="Chưa có dịch vụ/lốp nào!")
    if row["total_amount"] <= 0:
        conn.close()
        raise HTTPException(status_code=400, detail="Tổng tiền phải lớn hơn 0!")

    cur.execute("UPDATE tickets SET status = 'CHO_THANH_TOAN' WHERE id = ?", (ticket_id,))
    conn.commit()
    conn.close()
    await ws_manager.broadcast({"event": "TECH_COMPLETED", "message": f"Xe {row['plate_number']} đã hoàn thành dịch vụ!"})
    return {"status": "success"}

@app.post("/api/tickets/{ticket_id}/confirm-stock")
async def confirm_stock(ticket_id: int):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT item_id, item_name, quantity, cost_price FROM ticket_items WHERE ticket_id = ? AND item_type = 'PRODUCT'", (ticket_id,))
    products = cur.fetchall()
    for p in products:
        p_id = p["item_id"]
        qty = int(p["quantity"])
        cur.execute("SELECT stock_quantity FROM products WHERE id = ?", (p_id,))
        prod = cur.fetchone()
        if not prod or prod["stock_quantity"] < qty:
            conn.close()
            raise HTTPException(status_code=400, detail=f"Sản phẩm {p['item_name']} không đủ tồn kho!")
        cur.execute("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?", (qty, p_id))
    cur.execute("UPDATE tickets SET is_stock_exported = 1 WHERE id = ?", (ticket_id,))
    conn.commit()
    conn.close()
    await ws_manager.broadcast({"event": "STOCK_EXPORTED", "ticket_id": ticket_id})
    return {"status": "success"}

@app.post("/api/tickets/{ticket_id}/cashier-complete")
async def cashier_complete(ticket_id: int, req: CashierCompleteReq):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT is_stock_exported FROM tickets WHERE id = ?", (ticket_id,))
    t = cur.fetchone()
    cur.execute("SELECT COUNT(*) FROM ticket_items WHERE ticket_id = ? AND item_type = 'PRODUCT'", (ticket_id,))
    if cur.fetchone()[0] > 0 and t["is_stock_exported"] != 1:
        conn.close()
        raise HTTPException(status_code=400, detail="Kế toán phải xác nhận xuất kho trước!")

    cur.execute("UPDATE tickets SET status = 'HOAN_TAT', is_paid = 1, payment_method = ?, completed_at = CURRENT_TIMESTAMP WHERE id = ?", (req.payment_method, ticket_id))
    conn.commit()
    conn.close()
    await ws_manager.broadcast({"event": "TICKET_FINISHED"})
    return {"status": "success"}

@app.get("/api/reports")
def get_reports(from_date: str, to_date: str, role: str = "KE_TOAN"):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT total_amount, payment_method FROM tickets WHERE status = 'HOAN_TAT' AND date(completed_at) BETWEEN ? AND ?", (from_date, to_date))
    rows = cur.fetchall()
    rev = sum(r["total_amount"] for r in rows)
    res = {"role": role, "total_revenue": rev}
    if role == "QUAN_LY":
        cur.execute("SELECT SUM(ti.cost_price * ti.quantity) FROM ticket_items ti JOIN tickets t ON ti.ticket_id = t.id WHERE t.status = 'HOAN_TAT' AND date(t.completed_at) BETWEEN ? AND ?", (from_date, to_date))
        cost = cur.fetchone()[0] or 0.0
        res["total_cost"] = cost
        res["gross_profit"] = rev - cost
        res["margin_pct"] = round(((rev - cost) / rev * 100), 1) if rev > 0 else 0
    conn.close()
    return res

@app.get("/", response_class=HTMLResponse)
def index():
    with open(os.path.join(os.path.dirname(__file__), "templates", "index.html"), "r", encoding="utf-8") as f:
        return f.read()
'''
with open(os.path.join(base_dir, "server.py"), "w", encoding="utf-8") as f:
    f.write(server_code)

# 4. templates/index.html
html_content = '''<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Lốp Xe Local Pro</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background-color: #f4f6f9; font-family: sans-serif; }
    .hidden { display: none !important; }
  </style>
</head>
<body>
  <nav class="navbar navbar-dark bg-dark px-3">
    <a class="navbar-brand fw-bold text-warning" href="#"><i class="fa-solid fa-car me-2"></i>LỐP XE LOCAL PRO</a>
    <div>
      <span id="role-badge" class="badge bg-primary me-2">Chưa đăng nhập</span>
      <button class="btn btn-sm btn-outline-light" onclick="new bootstrap.Modal(document.getElementById('loginModal')).show()">Đăng Nhập</button>
      <button class="btn btn-sm btn-danger ms-2" onclick="location.reload()">Đăng Xuất</button>
    </div>
  </nav>

  <div class="modal fade" id="loginModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-dark text-white"><h6 class="modal-title">Chọn Tài Khoản</h6></div>
        <div class="modal-body">
          <select id="login-user" class="form-select mb-2">
            <option value="kythuat">kythuat (Kỹ Thuật Viên)</option>
            <option value="ketoan">ketoan (Kế Toán - Ẩn Giá Vốn)</option>
            <option value="quanly">quanly (Quản Lý - Full Quyền)</option>
          </select>
          <input type="password" id="login-pass" class="form-control mb-3" value="123456">
          <button class="btn btn-primary w-100" onclick="login()">Vào Hệ Thống</button>
        </div>
      </div>
    </div>
  </div>

  <div class="container-fluid mt-3">
    <ul class="nav nav-pills mb-3 bg-white p-2 rounded shadow-sm">
      <li class="nav-item"><button class="nav-link active" onclick="switchView('tech')">Kỹ Thuật</button></li>
      <li class="nav-item"><button class="nav-link" onclick="switchView('cashier')">Kế Toán</button></li>
      <li class="nav-item"><button class="nav-link" onclick="switchView('manager')">Quản Lý & Kho</button></li>
    </ul>

    <!-- Kỹ Thuật -->
    <div id="view-tech">
      <div class="row">
        <div class="col-md-4">
          <div class="card p-3 mb-3 shadow-sm">
            <h6>Tiếp Nhận Xe</h6>
            <select id="tech-lane-select" class="form-select form-select-sm mb-2"></select>
            <input type="text" id="tech-plate" class="form-control form-control-sm text-uppercase fw-bold text-danger mb-2" placeholder="81A-123.45">
            <button class="btn btn-sm btn-success w-100" onclick="createTicket()">+ Tiếp Nhận</button>
          </div>
        </div>
        <div class="col-md-8">
          <div class="card p-3 shadow-sm">
            <h6>Danh Sách Xe Đang Tại Xưởng</h6>
            <table class="table table-sm align-middle">
              <thead><tr><th>Mã</th><th>Làn</th><th>Biển số</th><th>Thợ</th><th>Tổng tiền</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
              <tbody id="tech-table"></tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- Kế Toán -->
    <div id="view-cashier" class="hidden">
      <div class="card p-3 shadow-sm">
        <h6 class="text-success fw-bold">Thu Ngân & Xuất Kho</h6>
        <table class="table table-sm align-middle">
          <thead><tr><th>Mã</th><th>Biển số</th><th>Thợ</th><th>Dịch vụ/Lốp</th><th>Tổng tiền</th><th>Xuất kho</th><th>Hình thức</th><th>Hoàn tất</th></tr></thead>
          <tbody id="cashier-table"></tbody>
        </table>
      </div>
    </div>

    <!-- Quản Lý -->
    <div id="view-manager" class="hidden">
      <div class="row mb-3">
        <div class="col-md-4"><div class="card p-3 bg-light"><span>Doanh thu:</span><h4 id="stat-rev" class="text-primary fw-bold">0 đ</h4></div></div>
        <div class="col-md-4" id="box-cost"><div class="card p-3 bg-light"><span>Giá vốn (Cost):</span><h4 id="stat-cost" class="text-warning fw-bold">0 đ</h4></div></div>
        <div class="col-md-4" id="box-profit"><div class="card p-3 bg-light"><span>Lợi nhuận gộp:</span><h4 id="stat-profit" class="text-success fw-bold">0 đ</h4></div></div>
      </div>
      <div class="card p-3 shadow-sm">
        <h6>Tồn Kho Thực Tế</h6>
        <table class="table table-sm table-bordered align-middle">
          <thead><tr><th>SKU</th><th>Tên hàng</th><th>Danh mục</th><th id="th-cost">Giá vốn</th><th>Giá bán lẻ</th><th>Tồn</th></tr></thead>
          <tbody id="inv-table"></tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Modal Chi Tiết Vé -->
  <div class="modal fade" id="ticketModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-primary text-white py-2"><h6 class="modal-title">Chọn Dịch Vụ</h6></div>
        <div class="modal-body small">
          <input type="hidden" id="modal-tid">
          <input type="text" id="modal-plate" class="form-control form-control-sm text-uppercase fw-bold mb-2">
          <select id="modal-tech" class="form-select form-select-sm mb-3"></select>
          <div id="modal-items" class="border p-2 mb-2 bg-light"></div>
          <div class="d-flex gap-2">
            <select id="modal-add-sel" class="form-select form-select-sm"></select>
            <input type="number" id="modal-add-qty" class="form-control form-control-sm" style="width:70px" value="1">
            <button class="btn btn-sm btn-outline-primary" onclick="addItem()">Thêm</button>
          </div>
          <div class="text-end mt-3 fw-bold text-danger">Tổng: <span id="modal-total">0</span> đ</div>
        </div>
        <div class="modal-footer py-1">
          <button class="btn btn-sm btn-primary" onclick="saveTicket()">Lưu</button>
          <button class="btn btn-sm btn-success" onclick="completeTicket()">Báo Hoàn Thành</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
  <script>
    let role = 'KY_THUAT';
    let catalog = { lanes: [], employees: [], services: [], products: [] };
    let curItems = [];

    const ws = new WebSocket(`ws://${location.host}/ws`);
    ws.onmessage = (e) => {
      const d = JSON.parse(e.data);
      if (d.event === 'TECH_COMPLETED') alert(d.message);
      loadTickets();
      if (role === 'QUAN_LY') loadReports();
    };

    async function login() {
      const u = document.getElementById('login-user').value;
      const p = document.getElementById('login-pass').value;
      const r = await fetch('/api/login', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({username:u, password:p})});
      if(r.ok) {
        const data = await r.json();
        role = data.role;
        document.getElementById('role-badge').innerText = `${data.fullname} (${role})`;
        bootstrap.Modal.getInstance(document.getElementById('loginModal')).hide();
        if(role==='KE_TOAN') { document.getElementById('box-cost').classList.add('hidden'); document.getElementById('box-profit').classList.add('hidden'); document.getElementById('th-cost').classList.add('hidden'); switchView('cashier'); }
        else if(role==='QUAN_LY') { document.getElementById('box-cost').classList.remove('hidden'); document.getElementById('box-profit').classList.remove('hidden'); document.getElementById('th-cost').classList.remove('hidden'); switchView('manager'); }
        else switchView('tech');
        loadCatalog();
        loadTickets();
      } else alert("Sai tài khoản!");
    }

    function switchView(v) {
      document.getElementById('view-tech').classList.toggle('hidden', v!=='tech');
      document.getElementById('view-cashier').classList.toggle('hidden', v!=='cashier');
      document.getElementById('view-manager').classList.toggle('hidden', v!=='manager');
      if(v==='manager') loadReports();
    }

    async function loadCatalog() {
      const r = await fetch(`/api/catalog?role=${role}`);
      catalog = await r.json();
      document.getElementById('tech-lane-select').innerHTML = catalog.lanes.map(l=>`<option value="${l.id}">${l.name}</option>`).join('');
      document.getElementById('modal-tech').innerHTML = '<option value="">-- Chọn Thợ --</option>' + catalog.employees.map(e=>`<option value="${e.id}">${e.name}</option>`).join('');
      
      let html = '<optgroup label="Dịch vụ">';
      catalog.services.forEach(s=> html+=`<option value="SERVICE_${s.id}_${s.price}">[DV] ${s.name} (${s.price.toLocaleString()}đ)</option>`);
      html += '</optgroup><optgroup label="Sản phẩm">';
      catalog.products.forEach(p=> html+=`<option value="PRODUCT_${p.id}_${p.sell_price}">[Kho] ${p.name} (${p.sell_price.toLocaleString()}đ)</option>`);
      html += '</optgroup>';
      document.getElementById('modal-add-sel').innerHTML = html;

      document.getElementById('inv-table').innerHTML = catalog.products.map(p=>`
        <tr><td>${p.sku}</td><td>${p.name}</td><td>${p.category}</td>
        ${role==='QUAN_LY'?`<td class="text-warning fw-bold">${(p.cost_price||0).toLocaleString()} đ</td>`:''}
        <td class="text-primary fw-bold">${p.sell_price.toLocaleString()} đ</td><td>${p.stock_quantity}</td></tr>
      `).join('');
    }

    async function loadTickets() {
      const r = await fetch('/api/tickets');
      const tickets = await r.json();
      document.getElementById('tech-table').innerHTML = tickets.map(t=>`
        <tr><td>#${t.id}</td><td>${t.lane_name}</td><td class="text-danger fw-bold">${t.plate_number}</td><td>${t.tech_name||'---'}</td>
        <td class="fw-bold">${t.total_amount.toLocaleString()} đ</td><td><span class="badge bg-secondary">${t.status}</span></td>
        <td><button class="btn btn-xs btn-outline-primary btn-sm" onclick='openModal(${JSON.stringify(t)})'>Chọn DV</button></td></tr>
      `).join('');

      document.getElementById('cashier-table').innerHTML = tickets.map(t=>`
        <tr><td>#${t.id}</td><td class="text-danger fw-bold">${t.plate_number}</td><td>${t.tech_name||'---'}</td>
        <td>${t.items.map(i=>`<span class="badge bg-light text-dark border">${i.item_name} x${i.quantity}</span>`).join(' ')}</td>
        <td class="text-primary fw-bold">${t.total_amount.toLocaleString()} đ</td>
        <td>${t.is_stock_exported?'<span class="badge bg-success">Đã xuất</span>':`<button class="btn btn-xs btn-warning btn-sm" onclick="confirmStock(${t.id})">Xuất kho</button>`}</td>
        <td><select id="pay-${t.id}" class="form-select form-select-sm"><option value="TIEN_MAT">Tiền mặt</option><option value="CHUYEN_KHOAN">Chuyển khoản</option></select></td>
        <td><button class="btn btn-xs btn-success btn-sm" onclick="cashierComplete(${t.id})">Hoàn tất</button></td></tr>
      `).join('');
    }

    async function createTicket() {
      const p = document.getElementById('tech-plate').value;
      const l = document.getElementById('tech-lane-select').value;
      if(!p) return alert("Nhập biển số!");
      const r = await fetch('/api/tickets', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({lane_id:l, plate_number:p})});
      if(r.ok) { document.getElementById('tech-plate').value=''; loadTickets(); }
      else alert((await r.json()).detail);
    }

    function openModal(t) {
      document.getElementById('modal-tid').value = t.id;
      document.getElementById('modal-plate').value = t.plate_number;
      document.getElementById('modal-tech').value = t.technician_id || '';
      curItems = t.items.map(i=>({item_type:i.item_type, item_id:i.item_id, item_name:i.item_name, quantity:i.quantity, unit_price:i.unit_price}));
      renderModalItems();
      new bootstrap.Modal(document.getElementById('ticketModal')).show();
    }

    function renderModalItems() {
      let tot = 0;
      document.getElementById('modal-items').innerHTML = curItems.map((it, idx)=>{
        const line = it.quantity * it.unit_price; tot += line;
        return `<div class="d-flex justify-content-between mb-1"><span>${it.item_name} x${it.quantity}</span><span>${line.toLocaleString()} đ <a href="#" class="text-danger ms-2" onclick="curItems.splice(${idx},1);renderModalItems();">&times;</a></span></div>`;
      }).join('');
      document.getElementById('modal-total').innerText = tot.toLocaleString();
    }

    function addItem() {
      const val = document.getElementById('modal-add-sel').value.split('_');
      const qty = parseFloat(document.getElementById('modal-add-qty').value)||1;
      const type = val[0], id = parseInt(val[1]), price = parseFloat(val[2]);
      const name = type==='SERVICE'? catalog.services.find(s=>s.id===id).name : catalog.products.find(p=>p.id===id).name;
      curItems.push({item_type:type, item_id:id, item_name:name, quantity:qty, unit_price:price});
      renderModalItems();
    }

    async function saveTicket() {
      const tid = document.getElementById('modal-tid').value;
      const tech = document.getElementById('modal-tech').value;
      const p = document.getElementById('modal-plate').value;
      const r = await fetch(`/api/tickets/${tid}/tech-update`, {
        method:'PUT', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({technician_id: tech?parseInt(tech):null, plate_number:p, items:curItems})
      });
      if(r.ok) { bootstrap.Modal.getInstance(document.getElementById('ticketModal')).hide(); loadTickets(); }
      else alert((await r.json()).detail);
    }

    async function completeTicket() {
      const tid = document.getElementById('modal-tid').value;
      await saveTicket();
      const r = await fetch(`/api/tickets/${tid}/tech-complete`, {method:'POST'});
      if(r.ok) { alert("Báo xong!"); loadTickets(); } else alert((await r.json()).detail);
    }

    async function confirmStock(tid) {
      const r = await fetch(`/api/tickets/${tid}/confirm-stock`, {method:'POST'});
      if(r.ok) { alert("Đã xuất kho!"); loadTickets(); loadCatalog(); } else alert((await r.json()).detail);
    }

    async function cashierComplete(tid) {
      const m = document.getElementById(`pay-${tid}`).value;
      const r = await fetch(`/api/tickets/${tid}/cashier-complete`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({payment_method:m})});
      if(r.ok) { alert("Hoàn tất xe!"); loadTickets(); } else alert((await r.json()).detail);
    }

    async function loadReports() {
      const today = new Date().toISOString().split('T')[0];
      const r = await fetch(`/api/reports?from_date=${today}&to_date=${today}&role=${role}`);
      const d = await r.json();
      document.getElementById('stat-rev').innerText = (d.total_revenue||0).toLocaleString() + ' đ';
      if(role==='QUAN_LY') {
        document.getElementById('stat-cost').innerText = (d.total_cost||0).toLocaleString() + ' đ';
        document.getElementById('stat-profit').innerText = (d.gross_profit||0).toLocaleString() + ' đ (' + (d.margin_pct||0) + '%)';
      }
    }

    loadCatalog();
    loadTickets();
  </script>
</body>
</html>
'''
with open(os.path.join(base_dir, "templates", "index.html"), "w", encoding="utf-8") as f:
    f.write(html_content)

print("ĐÃ TẠO TOÀN BỘ FILE THÀNH CÔNG VÀO THƯ MỤC NÀY!")
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using Microsoft.Web.WebView2.WinForms;

namespace LopXeClient;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

internal sealed class ClientSettings
{
    public string ServerUrl { get; set; } = "";
    public string ServerName { get; set; } = "";
    public string Role { get; set; } = "manager";
}

internal sealed class MainForm : Form
{
    private const int DiscoveryPort = 43991;
    private readonly string settingsFile = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "LopXePro", "client.json");
    private readonly WebView2 web = new() { Dock = DockStyle.Fill };
    private readonly ToolStripStatusLabel status = new("Chưa kết nối");
    private readonly ToolStripComboBox role = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private ClientSettings settings = new();

    public MainForm()
    {
        Text = "Lốp Xe Client";
        WindowState = FormWindowState.Maximized;
        MinimumSize = new Size(900, 600);
        BuildUi();
        Shown += async (_, _) => await StartAsync();
    }

    private void BuildUi()
    {
        var tools = new ToolStrip { GripStyle = ToolStripGripStyle.Hidden, Padding = new Padding(8, 5, 8, 5) };
        tools.Items.Add(new ToolStripLabel("LỐP XE CLIENT") { Font = new Font("Segoe UI", 11, FontStyle.Bold) });
        tools.Items.Add(new ToolStripSeparator());
        tools.Items.Add(new ToolStripLabel("Máy sử dụng:"));
        role.Items.AddRange(new object[] { "Quản lý", "Kế toán", "Kỹ thuật" });
        role.SelectedIndexChanged += (_, _) => { settings.Role = RoleCode(); SaveSettings(); Navigate(); };
        tools.Items.Add(role);
        tools.Items.Add(new ToolStripSeparator());
        var autoButton = new ToolStripButton("Tự tìm Server");
        autoButton.Click += async (_, _) => await AutoDiscoverAsync();
        tools.Items.Add(autoButton);
        var manualButton = new ToolStripButton("Cấu hình thủ công");
        manualButton.Click += (_, _) => ManualConfigure();
        tools.Items.Add(manualButton);
        var refreshButton = new ToolStripButton("Tải lại");
        refreshButton.Click += (_, _) => web.Reload();
        tools.Items.Add(refreshButton);

        var statusStrip = new StatusStrip();
        statusStrip.Items.Add(status);
        Controls.Add(web);
        Controls.Add(statusStrip);
        Controls.Add(tools);
        tools.Dock = DockStyle.Top;
        statusStrip.Dock = DockStyle.Bottom;
    }

    private async Task StartAsync()
    {
        LoadSettings();
        role.SelectedIndex = settings.Role switch { "accountant" => 1, "tech" => 2, _ => 0 };
        try
        {
            await web.EnsureCoreWebView2Async();
            web.CoreWebView2.Settings.AreDevToolsEnabled = false;
            web.CoreWebView2.Settings.IsStatusBarEnabled = false;
            web.CoreWebView2.NavigationCompleted += (_, e) =>
                status.Text = e.IsSuccess ? $"Đã kết nối {settings.ServerName}" : "Không tải được phần mềm";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Không khởi tạo được Microsoft Edge WebView2. Hãy chạy lại bộ cài Client.\n\n" + ex.Message,
                "Thiếu WebView2", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        if (!string.IsNullOrWhiteSpace(settings.ServerUrl)) Navigate();
        else await AutoDiscoverAsync();
    }

    private string RoleCode() => role.SelectedIndex switch { 1 => "accountant", 2 => "tech", _ => "manager" };

    private async Task AutoDiscoverAsync()
    {
        status.Text = "Đang tự tìm Lốp Xe Server trong LAN…";
        try
        {
            using var udp = new UdpClient();
            udp.EnableBroadcast = true;
            var request = Encoding.UTF8.GetBytes("LOPXE_DISCOVER_V1");
            await udp.SendAsync(request, request.Length, new IPEndPoint(IPAddress.Broadcast, DiscoveryPort));
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(4));
            var response = await udp.ReceiveAsync(timeout.Token);
            using var json = JsonDocument.Parse(response.Buffer);
            var root = json.RootElement;
            if (root.GetProperty("type").GetString() != "LOPXE_SERVER_V1") throw new InvalidDataException();
            var url = root.GetProperty("webAppUrl").GetString() ?? "";
            if (!IsAllowedUrl(url)) throw new InvalidDataException("Server trả về URL không an toàn.");
            settings.ServerUrl = url.TrimEnd('/');
            settings.ServerName = root.TryGetProperty("serverName", out var name) ? name.GetString() ?? "Server" : "Server";
            settings.Role = RoleCode();
            SaveSettings();
            Navigate();
        }
        catch (Exception)
        {
            status.Text = "Không tìm thấy Server. Có thể cấu hình thủ công.";
            var result = MessageBox.Show("Không tìm thấy Lốp Xe Server trong mạng LAN. Mở cấu hình thủ công?",
                "Tự tìm Server", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes) ManualConfigure();
        }
    }

    private void ManualConfigure()
    {
        using var form = new Form { Text = "Cấu hình kết nối thủ công", Width = 680, Height = 210, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false };
        var label = new Label { Left = 20, Top = 18, Width = 620, Text = "Nhập Google Apps Script Web App URL (https://.../exec):" };
        var input = new TextBox { Left = 20, Top = 48, Width = 620, Text = settings.ServerUrl };
        var save = new Button { Text = "Kiểm tra & lưu", Left = 480, Top = 95, Width = 160, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "Hủy", Left = 370, Top = 95, Width = 100, DialogResult = DialogResult.Cancel };
        form.Controls.AddRange(new Control[] { label, input, save, cancel });
        form.AcceptButton = save; form.CancelButton = cancel;
        if (form.ShowDialog(this) != DialogResult.OK) return;
        var url = input.Text.Trim();
        if (!IsAllowedUrl(url))
        {
            MessageBox.Show("Chỉ chấp nhận URL HTTPS, hoặc HTTP với địa chỉ mạng nội bộ.", "URL không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        settings.ServerUrl = url.TrimEnd('/');
        settings.ServerName = "Cấu hình thủ công";
        settings.Role = RoleCode();
        SaveSettings();
        Navigate();
    }

    private static bool IsAllowedUrl(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return false;
        if (uri.Scheme == Uri.UriSchemeHttps) return true;
        if (uri.Scheme != Uri.UriSchemeHttp) return false;
        if (uri.Host.EndsWith(".local", StringComparison.OrdinalIgnoreCase) || uri.Host.Equals("localhost", StringComparison.OrdinalIgnoreCase)) return true;
        return IPAddress.TryParse(uri.Host, out var ip) && IsPrivate(ip);
    }

    private static bool IsPrivate(IPAddress ip)
    {
        var b = ip.GetAddressBytes();
        return b.Length == 4 && (b[0] == 10 || (b[0] == 172 && b[1] is >= 16 and <= 31) || (b[0] == 192 && b[1] == 168));
    }

    private void Navigate()
    {
        if (web.CoreWebView2 == null || string.IsNullOrWhiteSpace(settings.ServerUrl)) return;
        var separator = settings.ServerUrl.Contains('?') ? "&" : "?";
        web.Source = new Uri(settings.ServerUrl + separator + "device=windows-client&role=" + Uri.EscapeDataString(settings.Role));
        status.Text = "Đang tải phần mềm…";
    }

    private void LoadSettings()
    {
        try
        {
            if (File.Exists(settingsFile)) settings = JsonSerializer.Deserialize<ClientSettings>(File.ReadAllText(settingsFile)) ?? new();
        }
        catch { settings = new(); }
    }

    private void SaveSettings()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(settingsFile)!);
        File.WriteAllText(settingsFile, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
    }
}

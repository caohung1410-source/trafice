import cv2
import threading
import time
import sqlite3
import os
from ai_engine import read_plate_from_image
from database import DB_PATH

class CameraManager:
    def __init__(self):
        self.streams = {}
        self.last_frames = {}
        self.running = True
        self.ws_broadcast = None
        self.lock = threading.Lock()

    def set_broadcaster(self, func):
        self.ws_broadcast = func

    def start_all(self):
        if not os.path.exists(DB_PATH):
            return
        try:
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("SELECT id, lane_id, rtsp_url, name FROM cameras")
            cams = cur.fetchall()
            conn.close()
            for cam_id, lane_id, rtsp, name in cams:
                self.start_cam(cam_id, lane_id, rtsp)
        except Exception as e:
            print(f"[Camera Start All Error]: {e}")

    def start_cam(self, cam_id, lane_id, rtsp_url):
        with self.lock:
            if cam_id in self.streams and self.streams[cam_id].is_alive():
                return
            t = threading.Thread(target=self._worker, args=(cam_id, lane_id, rtsp_url), daemon=True)
            self.streams[cam_id] = t
            t.start()

    def _worker(self, cam_id, lane_id, rtsp_url):
        target = int(rtsp_url) if str(rtsp_url).isdigit() else rtsp_url
        os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "rtsp_transport;udp"
        cap = cv2.VideoCapture(target)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

        # Bộ phát hiện chuyển động quang học
        bg_subtractor = cv2.createBackgroundSubtractorMOG2(history=30, varThreshold=25, detectShadows=False)

        last_scan_time = 0
        last_detected_plate = ""
        last_plate_time = 0

        while self.running:
            if not cap.isOpened():
                time.sleep(3)
                cap.open(target)
                continue

            ret, frame = cap.read()
            if not ret or frame is None:
                time.sleep(1)
                continue

            # Tạo ảnh xem trước nhẹ
            try:
                h, w = frame.shape[:2]
                thumb = cv2.resize(frame, (480, int(h * (480.0 / w))), interpolation=cv2.INTER_AREA)
                _, buffer = cv2.imencode('.jpg', thumb, [int(cv2.IMWRITE_JPEG_QUALITY), 40])
                self.last_frames[cam_id] = buffer.tobytes()
            except Exception:
                pass

            now = time.time()
            if now - last_scan_time > 1.2:
                last_scan_time = now
                
                # Kiểm tra xem có vật thể/xe đang di chuyển vào làn không
                fg_mask = bg_subtractor.apply(thumb)
                motion_pixels = cv2.countNonZero(fg_mask)

                # Khi phát hiện có xe chuyển động (motion_pixels > ngưỡng)
                if motion_pixels > 2500:
                    if self.ws_broadcast:
                        self.ws_broadcast({"event": "AI_SCANNING", "cam_id": cam_id, "lane_id": lane_id})
                    
                    try:
                        plate, crop_path = read_plate_from_image(frame, save_crop=True)
                        if plate and len(plate) >= 7:
                            if plate != last_detected_plate or (now - last_plate_time > 45):
                                last_detected_plate = plate
                                last_plate_time = now
                                self._register_vehicle(lane_id, plate, crop_path)
                    except Exception as e:
                        print(f"[Cam {cam_id} AI Error]: {e}")

            time.sleep(0.01)
        cap.release()

    def _register_vehicle(self, lane_id, plate, crop_path):
        try:
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("SELECT id FROM tickets WHERE plate_number = ? AND status != 'HOAN_TAT'", (plate,))
            if not cur.fetchone():
                cur.execute(
                    "INSERT INTO tickets (lane_id, plate_number, plate_image_path, status) VALUES (?, ?, ?, 'CHO_TIEP_NHAN')", 
                    (int(lane_id or 1), plate, crop_path)
                )
                conn.commit()
                tid = cur.lastrowid
                if self.ws_broadcast:
                    self.ws_broadcast({
                        "event": "NEW_TICKET",
                        "ticket_id": tid,
                        "plate": plate,
                        "lane_id": lane_id,
                        "plate_image": crop_path
                    })
            conn.close()
        except Exception as e:
            print(f"[DB Error Register Vehicle]: {e}")

camera_mgr = CameraManager()

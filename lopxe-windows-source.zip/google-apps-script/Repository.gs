function db_() {
  const id = PropertiesService.getScriptProperties().getProperty('DATABASE_ID');
  if (!id) throw new Error('Chưa khởi tạo dữ liệu. Hãy gắn DATABASE_ID trước.');
  return SpreadsheetApp.openById(id);
}

function sheet_(name) {
  const sh = db_().getSheetByName(name);
  if (!sh) throw new Error('Không tìm thấy sheet: ' + name);
  return sh;
}

function headers_(name) {
  const sh = sheet_(name);
  const lastCol = Math.max(1, sh.getLastColumn());
  return sh.getRange(1, 1, 1, lastCol).getValues()[0].filter(x => String(x).trim() !== '');
}

function recoverVersionFromDate_(d) {
  if (!(d instanceof Date)) return String(d || '');
  const year = Number(Utilities.formatDate(d, APP.TZ, 'yyyy'));
  const month = Number(Utilities.formatDate(d, APP.TZ, 'M'));
  const day = Number(Utilities.formatDate(d, APP.TZ, 'd'));
  if (year >= 2000 && year <= 2099) return `${day}.${month}.${year - 2000}`;
  return Utilities.formatDate(d, APP.TZ, "yyyy-MM-dd'T'HH:mm:ss");
}

function normalizeCellValue_(value, sheetName, header) {
  if (value instanceof Date) {
    if (sheetName === APP.SHEETS.AGENTS && header === 'version') return recoverVersionFromDate_(value);
    return Utilities.formatDate(value, APP.TZ, "yyyy-MM-dd'T'HH:mm:ss");
  }
  return value;
}

function listObjects_(name) {
  const sh = sheet_(name);
  const lastRow = sh.getLastRow();
  const lastCol = sh.getLastColumn();
  if (lastRow <= 1 || lastCol <= 0) return [];
  const headers = sh.getRange(1, 1, 1, lastCol).getValues()[0];
  const values = sh.getRange(2, 1, lastRow - 1, lastCol).getValues();
  return values.map(row => {
    const o = {};
    headers.forEach((h, i) => {
      if (String(h || '').trim()) o[h] = normalizeCellValue_(row[i], name, h);
    });
    return o;
  });
}

function getByField_(name, field, value) {
  return listObjects_(name).find(x => String(x[field]) === String(value)) || null;
}

function applySheetFormats_(sh, name, headers) {
  const rows = Math.max(sh.getMaxRows(), 1000);
  function textCol(header) {
    const idx = headers.indexOf(header);
    if (idx >= 0) sh.getRange(1, idx + 1, rows, 1).setNumberFormat('@');
  }
  if (name === APP.SHEETS.AGENTS) textCol('version');
  if (name === APP.SHEETS.JOBS) {
    ['ticketNo','plate','phone','laneId','employeeId'].forEach(textCol);
  }
}

function ensureSheet_(ss, name, requiredHeaders) {
  let sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange(1, 1, 1, requiredHeaders.length).setValues([requiredHeaders]);
  } else {
    const lastCol = sh.getLastColumn();
    let current = [];
    if (lastCol > 0 && sh.getLastRow() > 0) {
      current = sh.getRange(1,1,1,lastCol).getValues()[0].map(x=>String(x||'').trim()).filter(Boolean);
    }
    if (!current.length) {
      sh.getRange(1,1,1,requiredHeaders.length).setValues([requiredHeaders]);
      current = requiredHeaders.slice();
    } else {
      const missing = requiredHeaders.filter(h => !current.includes(h));
      if (missing.length) sh.getRange(1, current.length + 1, 1, missing.length).setValues([missing]);
    }
  }
  sh.setFrozenRows(1);
  const allHeaders = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0];
  sh.getRange(1,1,1,sh.getLastColumn()).setFontWeight('bold');
  applySheetFormats_(sh, name, allHeaders);
  return sh;
}

function appendObject_(name, obj) {
  const sh = sheet_(name);
  const headers = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0];
  const rowNo = Math.max(2, sh.getLastRow() + 1);
  const values = headers.map(h => obj[h] !== undefined ? obj[h] : '');
  sh.getRange(rowNo,1,1,headers.length).setValues([values]);
  applySheetFormats_(sh, name, headers);
  return obj;
}

function updateById_(name, id, patch) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const sh = sheet_(name);
    const headers = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0];
    const idCol = headers.indexOf('id');
    if (idCol < 0) throw new Error(name + ' không có cột id.');
    const lastRow = sh.getLastRow();
    if (lastRow <= 1) throw new Error('Không tìm thấy bản ghi.');
    const ids = sh.getRange(2,idCol + 1,lastRow - 1,1).getValues().flat();
    const idx = ids.findIndex(v => String(v) === String(id));
    if (idx < 0) throw new Error('Không tìm thấy ID: ' + id);
    const rowNo = idx + 2;
    const current = sh.getRange(rowNo,1,1,headers.length).getValues()[0];
    const obj = {};
    headers.forEach((h,i)=>obj[h]=normalizeCellValue_(current[i], name, h));
    Object.keys(patch || {}).forEach(k => { if (headers.includes(k)) obj[k] = patch[k]; });
    if (headers.includes('updatedAt')) obj.updatedAt = nowIso_();
    sh.getRange(rowNo,1,1,headers.length).setValues([headers.map(h => obj[h] !== undefined ? obj[h] : '')]);
    applySheetFormats_(sh, name, headers);
    return obj;
  } finally {
    lock.releaseLock();
  }
}

function deleteById_(name, id) {
  const sh = sheet_(name);
  const headers = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0];
  const idCol = headers.indexOf('id');
  if (idCol < 0) throw new Error(name + ' không có cột id.');
  const lastRow = sh.getLastRow();
  if (lastRow <= 1) return { ok: true };
  const ids = sh.getRange(2,idCol + 1,lastRow - 1,1).getValues().flat();
  const idx = ids.findIndex(v => String(v) === String(id));
  if (idx < 0) return { ok: true };
  sh.deleteRow(idx + 2);
  return { ok: true };
}

function upsertSetting_(key, value, description) {
  const rows = listObjects_(APP.SHEETS.SETTINGS);
  const idx = rows.findIndex(x => String(x.key) === String(key));
  const obj = { key, value: String(value ?? ''), description: description || '', updatedAt: nowIso_() };
  const sh = sheet_(APP.SHEETS.SETTINGS);
  const headers = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0];
  if (idx < 0) appendObject_(APP.SHEETS.SETTINGS, obj);
  else sh.getRange(idx + 2,1,1,headers.length).setValues([headers.map(h => obj[h] ?? '')]);
  return obj;
}

function settingsMap_() {
  const map = {};
  listObjects_(APP.SHEETS.SETTINGS).forEach(x => map[x.key] = normalizeCellValue_(x.value, APP.SHEETS.SETTINGS, 'value'));
  return map;
}

function parseJsonArray_(text) {
  try {
    const arr = JSON.parse(String(text || '[]'));
    return Array.isArray(arr) ? arr : [];
  } catch (e) {
    return [];
  }
}

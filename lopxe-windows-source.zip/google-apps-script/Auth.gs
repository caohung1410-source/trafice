function pinPropertyForRole_(role) {
  role = normalizeRole_(role);
  if (role === APP.ROLES.ACCOUNTING) return 'ACCOUNTING_PIN_HASH';
  if (role === APP.ROLES.TECH) return 'TECH_PIN_HASH';
  return 'ADMIN_PIN_HASH';
}

function ensureRolePins_() {
  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty('ADMIN_PIN_HASH')) props.setProperty('ADMIN_PIN_HASH', sha256_('123456'));
  if (!props.getProperty('ACCOUNTING_PIN_HASH')) props.setProperty('ACCOUNTING_PIN_HASH', sha256_('234567'));
  if (!props.getProperty('TECH_PIN_HASH')) props.setProperty('TECH_PIN_HASH', sha256_('345678'));
}

function apiLogin(role, pin) {
  if (pin === undefined) { pin = role; role = APP.ROLES.ADMIN; }
  role = normalizeRole_(role);
  ensureRolePins_();
  const props = PropertiesService.getScriptProperties();
  const hash = props.getProperty(pinPropertyForRole_(role));
  if (!hash) throw new Error('Chưa thiết lập PIN cho ' + roleLabel_(role) + '.');
  if (sha256_(String(pin || '').trim()) !== hash) {
    Utilities.sleep(250);
    throw new Error('PIN không đúng.');
  }
  const authEpoch = props.getProperty('AUTH_EPOCH') || '1';
  const token = Utilities.getUuid().replace(/-/g, '');
  CacheService.getScriptCache().put('sess_' + token, JSON.stringify({ epoch: authEpoch, role: role }), APP.SESSION_TTL);
  return { ok: true, token, role, roleLabel: roleLabel_(role), expiresIn: APP.SESSION_TTL, app: APP.NAME, version: APP.VERSION };
}

function apiLogout(token) {
  if (token) CacheService.getScriptCache().remove('sess_' + token);
  return { ok: true };
}

function readSession_(token) {
  if (!token) throw new Error('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.');
  const raw = CacheService.getScriptCache().get('sess_' + token);
  if (!raw) throw new Error('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.');
  let session;
  try { session = JSON.parse(raw); } catch (e) { throw new Error('Phiên cũ không còn hợp lệ.'); }
  const currentEpoch = PropertiesService.getScriptProperties().getProperty('AUTH_EPOCH') || '1';
  if (!session || String(session.epoch) !== String(currentEpoch)) throw new Error('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.');
  session.role = normalizeRole_(session.role);
  return session;
}

function requireSession_(token) { return readSession_(token); }
function requireRole_(token, roles) {
  const session = readSession_(token);
  const allowed = (Array.isArray(roles) ? roles : [roles]).map(normalizeRole_);
  if (!allowed.includes(session.role)) throw new Error('Bạn không có quyền thực hiện chức năng này.');
  return session;
}

function bumpAuthEpoch_() {
  const props = PropertiesService.getScriptProperties();
  const next = String(Number(props.getProperty('AUTH_EPOCH') || '1') + 1);
  props.setProperty('AUTH_EPOCH', next);
  return next;
}

function apiChangeRolePin(token, role, newPin) {
  requireRole_(token, APP.ROLES.ADMIN);
  role = normalizeRole_(role);
  const pin = String(newPin || '').trim();
  if (!/^\d{6,12}$/.test(pin)) throw new Error('PIN phải gồm 6-12 chữ số.');
  PropertiesService.getScriptProperties().setProperty(pinPropertyForRole_(role), sha256_(pin));
  bumpAuthEpoch_();
  return { ok: true, role, roleLabel: roleLabel_(role) };
}

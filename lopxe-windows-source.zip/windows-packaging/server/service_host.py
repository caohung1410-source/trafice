from __future__ import annotations

import json
import logging
import os
import socket
import subprocess
import sys
import threading
import time
import ctypes
from pathlib import Path

from server_config import APP_VERSION, DATA_DIR, generate_camera_configs, load_server_config


APP_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
STOP_FLAG = DATA_DIR / "stop.flag"
LOG_FILE = DATA_DIR / "logs" / "service-host.log"
PID_FILE = DATA_DIR / "service-host.pid"
ERROR_ALREADY_EXISTS = 183


def setup_logging() -> None:
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[logging.FileHandler(LOG_FILE, encoding="utf-8")],
    )


def acquire_single_instance():
    """Keep one host per Windows machine so cameras are never processed twice."""
    if os.name != "nt":
        return object()
    handle = ctypes.windll.kernel32.CreateMutexW(None, False, "Global\\LopXeProServiceHostV1")
    if not handle or ctypes.windll.kernel32.GetLastError() == ERROR_ALREADY_EXISTS:
        if handle:
            ctypes.windll.kernel32.CloseHandle(handle)
        return None
    return handle


class DiscoveryServer(threading.Thread):
    def __init__(self, config: dict):
        super().__init__(daemon=True)
        self.config = config
        self.running = True
        self.sock: socket.socket | None = None

    def run(self) -> None:
        port = int(self.config.get("udp_discovery_port", 43991))
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind(("0.0.0.0", port))
            self.sock.settimeout(1.0)
        except OSError as exc:
            logging.error("Không mở được cổng tự tìm Server %s: %s", port, exc)
            return

        while self.running:
            try:
                data, address = self.sock.recvfrom(2048)
                if data.strip() != b"LOPXE_DISCOVER_V1":
                    continue
                response = {
                    "type": "LOPXE_SERVER_V1",
                    "serverName": self.config.get("server_name", "LOPXE-SERVER"),
                    "webAppUrl": self.config.get("web_app_url", ""),
                    "version": APP_VERSION,
                }
                self.sock.sendto(json.dumps(response).encode("utf-8"), address)
            except socket.timeout:
                pass
            except OSError:
                break

    def stop(self) -> None:
        self.running = False
        if self.sock:
            self.sock.close()


def start_agent(config_path: Path) -> subprocess.Popen:
    exe = APP_DIR / "LopXeAI" / "LopXeAI.exe"
    if not exe.exists():
        raise FileNotFoundError(f"Không tìm thấy {exe}")
    env = os.environ.copy()
    env["LOPXE_EASYOCR_MODEL_DIR"] = str(DATA_DIR / "models" / "easyocr")
    flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    return subprocess.Popen([str(exe), "--config", str(config_path)], cwd=str(exe.parent), env=env, creationflags=flags)


def main() -> int:
    setup_logging()
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    mutex = acquire_single_instance()
    if mutex is None:
        logging.warning("Lốp Xe Server đang chạy; bỏ qua yêu cầu mở thêm tiến trình.")
        return 0
    STOP_FLAG.unlink(missing_ok=True)
    PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    config = load_server_config()
    discovery = DiscoveryServer(config)
    discovery.start()
    processes: dict[str, tuple[Path, subprocess.Popen]] = {}

    if not config.get("web_app_url") or not config.get("api_key"):
        logging.warning("Chưa cấu hình Google Apps Script URL/API key. Chỉ chạy dịch vụ tự tìm Server.")

    for camera, path in generate_camera_configs(config, APP_DIR):
        camera_id = str(camera.get("id") or path.stem)
        try:
            processes[camera_id] = (path, start_agent(path))
            logging.info("Đã chạy AI cho %s", camera_id)
        except Exception:
            logging.exception("Không khởi động được AI cho %s", camera_id)

    try:
        while not STOP_FLAG.exists():
            time.sleep(3)
            for camera_id, (path, process) in list(processes.items()):
                if process.poll() is None:
                    continue
                logging.warning("AI %s đã dừng, khởi động lại sau 5 giây", camera_id)
                time.sleep(5)
                try:
                    processes[camera_id] = (path, start_agent(path))
                except Exception:
                    logging.exception("Khởi động lại AI %s thất bại", camera_id)
    finally:
        discovery.stop()
        for _, process in processes.values():
            if process.poll() is None:
                process.terminate()
        for _, process in processes.values():
            if process.poll() is None:
                try:
                    process.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    process.kill()
        STOP_FLAG.unlink(missing_ok=True)
        PID_FILE.unlink(missing_ok=True)
        if os.name == "nt" and mutex:
            ctypes.windll.kernel32.CloseHandle(mutex)
        logging.info("Lốp Xe Server đã dừng")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

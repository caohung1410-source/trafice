function sha256_(text) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(text));
  return bytes.map(b => ('0' + (b & 0xff).toString(16)).slice(-2)).join('');
}

function setupLopXePro_() {
  const props = PropertiesService.getScriptProperties();
  let ssId = props.getProperty('DATABASE_ID');
  let ss = ssId ? SpreadsheetApp.openById(ssId) : SpreadsheetApp.create('LopXePro_Data_' + Utilities.formatDate(new Date(), APP.TZ, 'yyyyMMdd_HHmm'));
  if (!ssId) props.setProperty('DATABASE_ID', ss.getId());
  try { ss.setSpreadsheetTimeZone(APP.TZ); } catch (e) {}

  Object.keys(APP.SHEETS).forEach(k => ensureSheet_(ss, APP.SHEETS[k], APP.HEADERS[k]));
  seedSettings_();
  seedRolePins_();
  seedEmployees_();
  seedServices_();
  seedLanes_();
  syncAllLaneCameras_();
  migrateLegacyJobs_();
  migrateAgentVersions_();
  if (!props.getProperty('AUTH_EPOCH')) props.setProperty('AUTH_EPOCH', '1');
  if (!props.getProperty('AI_API_KEY')) props.setProperty('AI_API_KEY', Utilities.getUuid().replace(/-/g,'') + Utilities.getUuid().replace(/-/g,''));

  return { ok: true, version: APP.VERSION, spreadsheetId: ss.getId(), spreadsheetUrl: ss.getUrl() };
}

function seedRolePins_() { ensureRolePins_(); }

function resetAdminPin_(){ PropertiesService.getScriptProperties().setProperty('ADMIN_PIN_HASH', sha256_('123456')); bumpAuthEpoch_(); return {ok:true}; }
function resetAccountingPin_(){ PropertiesService.getScriptProperties().setProperty('ACCOUNTING_PIN_HASH', sha256_('234567')); bumpAuthEpoch_(); return {ok:true}; }
function resetTechPin_(){ PropertiesService.getScriptProperties().setProperty('TECH_PIN_HASH', sha256_('345678')); bumpAuthEpoch_(); return {ok:true}; }
function rotateAiApiKey_(){ const k = Utilities.getUuid().replace(/-/g,'') + Utilities.getUuid().replace(/-/g,''); PropertiesService.getScriptProperties().setProperty('AI_API_KEY', k); return {ok:true, apiKey:k}; }

function seedSettings_() {
  const defaults = [
    ['SHOP_NAME','Lốp Xe Pro','Tên cửa hàng'],
    ['SHOP_PHONE','','Điện thoại'],
    ['SHOP_ADDRESS','','Địa chỉ'],
    ['TICKET_PREFIX','LX','Tiền tố phiếu'],
    ['AUTO_REFRESH_SECONDS','10','Refresh AI biển số'],
    ['AGENT_REFRESH_SECONDS','10','Refresh trạng thái AI'],
    ['AGENT_OFFLINE_SECONDS','90','Quá thời gian này hiển thị offline']
  ];
  defaults.forEach(x => { if (!getByField_(APP.SHEETS.SETTINGS, 'key', x[0])) appendObject_(APP.SHEETS.SETTINGS, { key:x[0], value:x[1], description:x[2], updatedAt:nowIso_() }); });
}

function seedEmployees_() {
  if (listObjects_(APP.SHEETS.EMPLOYEES).length) return;
  ['Nguyễn Văn An','Trần Minh Khoa','Lê Quốc Tuấn'].forEach((name, i) => appendObject_(APP.SHEETS.EMPLOYEES, { id:newId_('NV'), name, phone:'', role:'Kỹ thuật', active:true, createdAt:nowIso_(), updatedAt:nowIso_() }));
}

function seedServices_() {
  if (listObjects_(APP.SHEETS.SERVICES).length) return;
  [
    ['Kiểm tra lốp',0],['Vá lốp',80000],['Cân bằng động',100000],
    ['Đảo lốp',120000],['Bơm khí nitơ',160000],['Thay van',50000],['Thay lốp',1500000]
  ].forEach(x => appendObject_(APP.SHEETS.SERVICES, { id:newId_('DV'), name:x[0], description:'', defaultPrice:x[1], active:true, createdAt:nowIso_(), updatedAt:nowIso_() }));
}

function seedLanes_() {
  if (listObjects_(APP.SHEETS.LANES).length) return;
  [
    { name:'Làn 1', cameraCount:2 },
    { name:'Làn 2', cameraCount:1 },
    { name:'Làn 3', cameraCount:2 }
  ].forEach(x => appendObject_(APP.SHEETS.LANES, { id:newId_('LANE'), name:x.name, cameraCount:x.cameraCount, active:true, createdAt:nowIso_(), updatedAt:nowIso_() }));
}

function syncLaneCameras_(laneId) {
  const lane = getByField_(APP.SHEETS.LANES, 'id', laneId);
  if (!lane) return;
  const count = Math.max(0, Number(lane.cameraCount || 0));
  const all = listObjects_(APP.SHEETS.CAMERAS).filter(x => String(x.laneId) === String(lane.id));
  for (let i = 1; i <= count; i++) {
    const ex = all.find(x => Number(x.cameraNo) === i);
    if (!ex) appendObject_(APP.SHEETS.CAMERAS, {
      id:newId_('CAM'), laneId:lane.id, laneName:lane.name, cameraNo:i,
      name: lane.name + ' - Camera ' + i, model:'', rtspUrl:'', location:lane.name,
      enabled:true, createdAt:nowIso_(), updatedAt:nowIso_()
    });
  }
  all.filter(x => Number(x.cameraNo) > count).forEach(x => deleteById_(APP.SHEETS.CAMERAS, x.id));
  listObjects_(APP.SHEETS.CAMERAS).filter(x => String(x.laneId) === String(lane.id)).forEach(x => {
    if (String(x.laneName) !== String(lane.name) || String(x.location) !== String(lane.name)) {
      updateById_(APP.SHEETS.CAMERAS, x.id, { laneName: lane.name, location: lane.name, name: lane.name + ' - Camera ' + x.cameraNo });
    }
  });
}

function syncAllLaneCameras_() { listObjects_(APP.SHEETS.LANES).forEach(x => syncLaneCameras_(x.id)); }

function migrateAgentVersions_() {
  const sh = sheet_(APP.SHEETS.AGENTS);
  const headers = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0];
  const col = headers.indexOf('version') + 1;
  if (col <= 0 || sh.getLastRow() <= 1) return;
  sh.getRange(1,col,sh.getMaxRows(),1).setNumberFormat('@');
  const range = sh.getRange(2,col,sh.getLastRow() - 1,1);
  const vals = range.getValues();
  let changed = false;
  vals.forEach(row => { if (row[0] instanceof Date) { row[0] = recoverVersionFromDate_(row[0]); changed = true; } });
  if (changed) range.setValues(vals);
}

function migrateLegacyJobs_() {
  const sh = sheet_(APP.SHEETS.JOBS);
  const headers = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0];
  const lastRow = sh.getLastRow();
  if (lastRow <= 1) return;
  const values = sh.getRange(2,1,lastRow - 1,headers.length).getValues();
  const lanes = listObjects_(APP.SHEETS.LANES);
  const defaultLane = lanes[0] || null;
  let changed = false;
  values.forEach(row => {
    const obj = {};
    headers.forEach((h,i)=>obj[h]=normalizeCellValue_(row[i], APP.SHEETS.JOBS, h));
    if (!obj.serviceItemsJson) {
      const name = obj.serviceSummary || obj.serviceName || '';
      const price = safeNumber_(obj.amount || obj.unitPrice || 0);
      if (name) {
        obj.serviceItemsJson = JSON.stringify([{ id:'', name, qty:1, price, amount:price }]);
        obj.serviceSummary = name;
        obj.amount = price;
        changed = true;
      }
    }
    if (!obj.laneId && defaultLane) { obj.laneId = defaultLane.id; obj.laneName = defaultLane.name; changed = true; }
    if (!obj.status || obj.status === 'Mới tiếp nhận') { obj.status = APP.STATUS.RECEIVED; }
    else if (obj.status === 'Đang xử lý') { obj.status = APP.STATUS.WORKING; }
    else if (obj.status === 'Hoàn thành') { obj.status = (obj.paymentStatus === APP.PAYMENT.PAID ? APP.STATUS.CLOSED : APP.STATUS.TECH_DONE); changed = true; }
    if (obj.status === APP.STATUS.CLOSED && !obj.closedAt) { obj.closedAt = obj.paidAt || obj.completedAt || nowIso_(); changed = true; }
    if (!obj.paymentStatus) obj.paymentStatus = APP.PAYMENT.UNPAID;
    if (obj.inventoryConfirmed === '') obj.inventoryConfirmed = false;
    headers.forEach((h,i)=>row[i]=obj[h] !== undefined ? obj[h] : '');
  });
  if (changed) sh.getRange(2,1,lastRow - 1,headers.length).setValues(values);
}

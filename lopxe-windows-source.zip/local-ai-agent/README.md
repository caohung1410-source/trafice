# Lốp Xe Pro Hybrid v1.2 – ANPR Việt Nam

Nâng từ v1.1, giữ nguyên Google Apps Script và database hiện hữu.

## Pipeline v1.2
RTSP → ONNX detector → crop → perspective correction → OCR 4 biến thể
→ nhận biết biển 1 dòng/2 dòng → kiểm tra cú pháp biển Việt Nam
→ weighted multi-frame voting → chống trùng → Google Apps Script → Google Sheet.

## Mới trong v1.2
- Detector ONNX YOLO-family cho biển số.
- Chỉnh nghiêng/perspective.
- OCR CLAHE + sharpen + threshold + inverted threshold.
- Xử lý biển 1 dòng và 2 dòng.
- Sửa có kiểm soát lỗi O/0, I/1, S/5, B/8...
- Kiểm tra cấu trúc biển số Việt Nam trước khi chốt.
- Voting nhiều frame chịu sai lệch tối đa 1 ký tự.
- Gửi metadata detector/OCR/voting về GAS.
- Fallback detector hình học nếu thiếu ONNX.

## Cài Windows
1. `local-ai-agent/install.bat`
2. Sửa `config.yaml`
3. Đặt model tại `models/license_plate_detector.onnx` nếu có.
4. `run.bat`

## Google Apps Script
v1.2 Agent tương thích với GAS v1.1. Không cần tạo database mới.

## Lưu ý
Không tuyên bố 95–99% khi chưa đo trên clip/camera thật. Mục tiêu production phải benchmark bằng dữ liệu tại cửa hàng.

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$out = Join-Path $root "installer\output"
$models = Join-Path $out "server\easyocr-models"

Remove-Item -Recurse -Force $out -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $models | Out-Null

python -m pip install --upgrade pip
python -m pip install -r (Join-Path $root "requirements.txt") pyinstaller==6.16.0

# Download OCR models at build time: first use at the workshop does not need Internet.
$env:LOPXE_EASYOCR_MODEL_DIR = $models
python -c "import easyocr, os; easyocr.Reader(['en'], gpu=False, quantize=True, verbose=False, model_storage_directory=os.environ['LOPXE_EASYOCR_MODEL_DIR'], download_enabled=True)"

Push-Location $root
python -m PyInstaller --noconfirm --clean --onedir --windowed --name LopXeServer `
  --add-data "templates;templates" `
  --collect-all fastapi --collect-all starlette --collect-all uvicorn `
  --collect-all easyocr --collect-all reportlab --collect-all openpyxl `
  --hidden-import multipart --hidden-import google.oauth2.service_account launcher.py
Pop-Location

Copy-Item -Recurse -Force (Join-Path $root "dist\LopXeServer\*") (Join-Path $out "server")
& iscc (Join-Path $root "installer\LopXeServer.iss")
